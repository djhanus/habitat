# WordPress MySQL database migration
#
# Generated: Friday 11. January 2019 21:06 UTC
# Hostname: localhost
# Database: `wp_habitat`
# URL: //localhost:8888/habitat
# Path: /Users/bluelinedev/Development/habitat
# Tables: wp_commentmeta, wp_comments, wp_links, wp_options, wp_postmeta, wp_posts, wp_term_relationships, wp_term_taxonomy, wp_termmeta, wp_terms, wp_usermeta, wp_users
# Table Prefix: wp_
# Post Types: revision, acf-field, acf-field-group, attachment, nav_menu_item, page, post
# Protocol: http
# Multisite: false
# Subsite Export: false
# --------------------------------------------------------

/*!40101 SET NAMES utf8 */;

SET sql_mode='NO_AUTO_VALUE_ON_ZERO';



#
# Delete any existing table `wp_commentmeta`
#

DROP TABLE IF EXISTS `wp_commentmeta`;


#
# Table structure of table `wp_commentmeta`
#

CREATE TABLE `wp_commentmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `comment_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_520_ci,
  PRIMARY KEY (`meta_id`),
  KEY `comment_id` (`comment_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_commentmeta`
#

#
# End of data contents of table `wp_commentmeta`
# --------------------------------------------------------



#
# Delete any existing table `wp_comments`
#

DROP TABLE IF EXISTS `wp_comments`;


#
# Table structure of table `wp_comments`
#

CREATE TABLE `wp_comments` (
  `comment_ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `comment_post_ID` bigint(20) unsigned NOT NULL DEFAULT '0',
  `comment_author` tinytext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `comment_author_email` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_author_url` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_author_IP` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_content` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `comment_karma` int(11) NOT NULL DEFAULT '0',
  `comment_approved` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '1',
  `comment_agent` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_type` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `user_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`comment_ID`),
  KEY `comment_post_ID` (`comment_post_ID`),
  KEY `comment_approved_date_gmt` (`comment_approved`,`comment_date_gmt`),
  KEY `comment_date_gmt` (`comment_date_gmt`),
  KEY `comment_parent` (`comment_parent`),
  KEY `comment_author_email` (`comment_author_email`(10))
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_comments`
#
INSERT INTO `wp_comments` ( `comment_ID`, `comment_post_ID`, `comment_author`, `comment_author_email`, `comment_author_url`, `comment_author_IP`, `comment_date`, `comment_date_gmt`, `comment_content`, `comment_karma`, `comment_approved`, `comment_agent`, `comment_type`, `comment_parent`, `user_id`) VALUES
(1, 1, 'A WordPress Commenter', 'wapuu@wordpress.example', 'https://wordpress.org/', '', '2018-11-27 19:38:15', '2018-11-27 19:38:15', 'Hi, this is a comment.\nTo get started with moderating, editing, and deleting comments, please visit the Comments screen in the dashboard.\nCommenter avatars come from <a href="https://gravatar.com">Gravatar</a>.', 0, 'post-trashed', '', '', 0, 0) ;

#
# End of data contents of table `wp_comments`
# --------------------------------------------------------



#
# Delete any existing table `wp_links`
#

DROP TABLE IF EXISTS `wp_links`;


#
# Table structure of table `wp_links`
#

CREATE TABLE `wp_links` (
  `link_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `link_url` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_name` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_image` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_target` varchar(25) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_description` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_visible` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'Y',
  `link_owner` bigint(20) unsigned NOT NULL DEFAULT '1',
  `link_rating` int(11) NOT NULL DEFAULT '0',
  `link_updated` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `link_rel` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_notes` mediumtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `link_rss` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`link_id`),
  KEY `link_visible` (`link_visible`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_links`
#

#
# End of data contents of table `wp_links`
# --------------------------------------------------------



#
# Delete any existing table `wp_options`
#

DROP TABLE IF EXISTS `wp_options`;


#
# Table structure of table `wp_options`
#

CREATE TABLE `wp_options` (
  `option_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `option_name` varchar(191) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `option_value` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `autoload` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'yes',
  PRIMARY KEY (`option_id`),
  UNIQUE KEY `option_name` (`option_name`)
) ENGINE=InnoDB AUTO_INCREMENT=407 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_options`
#
INSERT INTO `wp_options` ( `option_id`, `option_name`, `option_value`, `autoload`) VALUES
(1, 'siteurl', 'http://localhost:8888/habitat', 'yes'),
(2, 'home', 'http://localhost:8888/habitat', 'yes'),
(3, 'blogname', 'Habitat for Humanity', 'yes'),
(4, 'blogdescription', 'Just another WordPress site', 'yes'),
(5, 'users_can_register', '0', 'yes'),
(6, 'admin_email', 'admin@thisisblueline.com', 'yes'),
(7, 'start_of_week', '1', 'yes'),
(8, 'use_balanceTags', '0', 'yes'),
(9, 'use_smilies', '1', 'yes'),
(10, 'require_name_email', '1', 'yes'),
(11, 'comments_notify', '1', 'yes'),
(12, 'posts_per_rss', '10', 'yes'),
(13, 'rss_use_excerpt', '0', 'yes'),
(14, 'mailserver_url', 'mail.example.com', 'yes'),
(15, 'mailserver_login', 'login@example.com', 'yes'),
(16, 'mailserver_pass', 'password', 'yes'),
(17, 'mailserver_port', '110', 'yes'),
(18, 'default_category', '1', 'yes'),
(19, 'default_comment_status', 'open', 'yes'),
(20, 'default_ping_status', 'open', 'yes'),
(21, 'default_pingback_flag', '0', 'yes'),
(22, 'posts_per_page', '10', 'yes'),
(23, 'date_format', 'F j, Y', 'yes'),
(24, 'time_format', 'g:i a', 'yes'),
(25, 'links_updated_date_format', 'F j, Y g:i a', 'yes'),
(26, 'comment_moderation', '0', 'yes'),
(27, 'moderation_notify', '1', 'yes'),
(28, 'permalink_structure', '/%year%/%monthnum%/%day%/%postname%/', 'yes'),
(29, 'rewrite_rules', 'a:90:{s:11:"^wp-json/?$";s:22:"index.php?rest_route=/";s:14:"^wp-json/(.*)?";s:33:"index.php?rest_route=/$matches[1]";s:21:"^index.php/wp-json/?$";s:22:"index.php?rest_route=/";s:24:"^index.php/wp-json/(.*)?";s:33:"index.php?rest_route=/$matches[1]";s:47:"category/(.+?)/feed/(feed|rdf|rss|rss2|atom)/?$";s:52:"index.php?category_name=$matches[1]&feed=$matches[2]";s:42:"category/(.+?)/(feed|rdf|rss|rss2|atom)/?$";s:52:"index.php?category_name=$matches[1]&feed=$matches[2]";s:23:"category/(.+?)/embed/?$";s:46:"index.php?category_name=$matches[1]&embed=true";s:35:"category/(.+?)/page/?([0-9]{1,})/?$";s:53:"index.php?category_name=$matches[1]&paged=$matches[2]";s:17:"category/(.+?)/?$";s:35:"index.php?category_name=$matches[1]";s:44:"tag/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?tag=$matches[1]&feed=$matches[2]";s:39:"tag/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?tag=$matches[1]&feed=$matches[2]";s:20:"tag/([^/]+)/embed/?$";s:36:"index.php?tag=$matches[1]&embed=true";s:32:"tag/([^/]+)/page/?([0-9]{1,})/?$";s:43:"index.php?tag=$matches[1]&paged=$matches[2]";s:14:"tag/([^/]+)/?$";s:25:"index.php?tag=$matches[1]";s:45:"type/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?post_format=$matches[1]&feed=$matches[2]";s:40:"type/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?post_format=$matches[1]&feed=$matches[2]";s:21:"type/([^/]+)/embed/?$";s:44:"index.php?post_format=$matches[1]&embed=true";s:33:"type/([^/]+)/page/?([0-9]{1,})/?$";s:51:"index.php?post_format=$matches[1]&paged=$matches[2]";s:15:"type/([^/]+)/?$";s:33:"index.php?post_format=$matches[1]";s:48:".*wp-(atom|rdf|rss|rss2|feed|commentsrss2)\\.php$";s:18:"index.php?feed=old";s:20:".*wp-app\\.php(/.*)?$";s:19:"index.php?error=403";s:18:".*wp-register.php$";s:23:"index.php?register=true";s:32:"feed/(feed|rdf|rss|rss2|atom)/?$";s:27:"index.php?&feed=$matches[1]";s:27:"(feed|rdf|rss|rss2|atom)/?$";s:27:"index.php?&feed=$matches[1]";s:8:"embed/?$";s:21:"index.php?&embed=true";s:20:"page/?([0-9]{1,})/?$";s:28:"index.php?&paged=$matches[1]";s:27:"comment-page-([0-9]{1,})/?$";s:39:"index.php?&page_id=23&cpage=$matches[1]";s:41:"comments/feed/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?&feed=$matches[1]&withcomments=1";s:36:"comments/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?&feed=$matches[1]&withcomments=1";s:17:"comments/embed/?$";s:21:"index.php?&embed=true";s:44:"search/(.+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:40:"index.php?s=$matches[1]&feed=$matches[2]";s:39:"search/(.+)/(feed|rdf|rss|rss2|atom)/?$";s:40:"index.php?s=$matches[1]&feed=$matches[2]";s:20:"search/(.+)/embed/?$";s:34:"index.php?s=$matches[1]&embed=true";s:32:"search/(.+)/page/?([0-9]{1,})/?$";s:41:"index.php?s=$matches[1]&paged=$matches[2]";s:14:"search/(.+)/?$";s:23:"index.php?s=$matches[1]";s:47:"author/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?author_name=$matches[1]&feed=$matches[2]";s:42:"author/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?author_name=$matches[1]&feed=$matches[2]";s:23:"author/([^/]+)/embed/?$";s:44:"index.php?author_name=$matches[1]&embed=true";s:35:"author/([^/]+)/page/?([0-9]{1,})/?$";s:51:"index.php?author_name=$matches[1]&paged=$matches[2]";s:17:"author/([^/]+)/?$";s:33:"index.php?author_name=$matches[1]";s:69:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/feed/(feed|rdf|rss|rss2|atom)/?$";s:80:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&feed=$matches[4]";s:64:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/(feed|rdf|rss|rss2|atom)/?$";s:80:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&feed=$matches[4]";s:45:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/embed/?$";s:74:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&embed=true";s:57:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/page/?([0-9]{1,})/?$";s:81:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&paged=$matches[4]";s:39:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/?$";s:63:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]";s:56:"([0-9]{4})/([0-9]{1,2})/feed/(feed|rdf|rss|rss2|atom)/?$";s:64:"index.php?year=$matches[1]&monthnum=$matches[2]&feed=$matches[3]";s:51:"([0-9]{4})/([0-9]{1,2})/(feed|rdf|rss|rss2|atom)/?$";s:64:"index.php?year=$matches[1]&monthnum=$matches[2]&feed=$matches[3]";s:32:"([0-9]{4})/([0-9]{1,2})/embed/?$";s:58:"index.php?year=$matches[1]&monthnum=$matches[2]&embed=true";s:44:"([0-9]{4})/([0-9]{1,2})/page/?([0-9]{1,})/?$";s:65:"index.php?year=$matches[1]&monthnum=$matches[2]&paged=$matches[3]";s:26:"([0-9]{4})/([0-9]{1,2})/?$";s:47:"index.php?year=$matches[1]&monthnum=$matches[2]";s:43:"([0-9]{4})/feed/(feed|rdf|rss|rss2|atom)/?$";s:43:"index.php?year=$matches[1]&feed=$matches[2]";s:38:"([0-9]{4})/(feed|rdf|rss|rss2|atom)/?$";s:43:"index.php?year=$matches[1]&feed=$matches[2]";s:19:"([0-9]{4})/embed/?$";s:37:"index.php?year=$matches[1]&embed=true";s:31:"([0-9]{4})/page/?([0-9]{1,})/?$";s:44:"index.php?year=$matches[1]&paged=$matches[2]";s:13:"([0-9]{4})/?$";s:26:"index.php?year=$matches[1]";s:58:"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:68:"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:88:"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:83:"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:83:"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:64:"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:53:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/embed/?$";s:91:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&embed=true";s:57:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/trackback/?$";s:85:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&tb=1";s:77:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:97:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&feed=$matches[5]";s:72:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:97:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&feed=$matches[5]";s:65:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/page/?([0-9]{1,})/?$";s:98:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&paged=$matches[5]";s:72:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/comment-page-([0-9]{1,})/?$";s:98:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&cpage=$matches[5]";s:61:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)(?:/([0-9]+))?/?$";s:97:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&page=$matches[5]";s:47:"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:57:"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:77:"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:72:"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:72:"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:53:"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:64:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/comment-page-([0-9]{1,})/?$";s:81:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&cpage=$matches[4]";s:51:"([0-9]{4})/([0-9]{1,2})/comment-page-([0-9]{1,})/?$";s:65:"index.php?year=$matches[1]&monthnum=$matches[2]&cpage=$matches[3]";s:38:"([0-9]{4})/comment-page-([0-9]{1,})/?$";s:44:"index.php?year=$matches[1]&cpage=$matches[2]";s:27:".?.+?/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:37:".?.+?/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:57:".?.+?/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:52:".?.+?/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:52:".?.+?/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:33:".?.+?/attachment/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:16:"(.?.+?)/embed/?$";s:41:"index.php?pagename=$matches[1]&embed=true";s:20:"(.?.+?)/trackback/?$";s:35:"index.php?pagename=$matches[1]&tb=1";s:40:"(.?.+?)/feed/(feed|rdf|rss|rss2|atom)/?$";s:47:"index.php?pagename=$matches[1]&feed=$matches[2]";s:35:"(.?.+?)/(feed|rdf|rss|rss2|atom)/?$";s:47:"index.php?pagename=$matches[1]&feed=$matches[2]";s:28:"(.?.+?)/page/?([0-9]{1,})/?$";s:48:"index.php?pagename=$matches[1]&paged=$matches[2]";s:35:"(.?.+?)/comment-page-([0-9]{1,})/?$";s:48:"index.php?pagename=$matches[1]&cpage=$matches[2]";s:24:"(.?.+?)(?:/([0-9]+))?/?$";s:47:"index.php?pagename=$matches[1]&page=$matches[2]";}', 'yes'),
(30, 'hack_file', '0', 'yes'),
(31, 'blog_charset', 'UTF-8', 'yes'),
(32, 'moderation_keys', '', 'no'),
(33, 'active_plugins', 'a:2:{i:0;s:34:"advanced-custom-fields-pro/acf.php";i:1;s:31:"wp-migrate-db/wp-migrate-db.php";}', 'yes'),
(34, 'category_base', '', 'yes'),
(35, 'ping_sites', 'http://rpc.pingomatic.com/', 'yes'),
(36, 'comment_max_links', '2', 'yes'),
(37, 'gmt_offset', '0', 'yes'),
(38, 'default_email_category', '1', 'yes'),
(39, 'recently_edited', '', 'no'),
(40, 'template', 'habitat', 'yes'),
(41, 'stylesheet', 'habitat', 'yes'),
(42, 'comment_whitelist', '1', 'yes'),
(43, 'blacklist_keys', '', 'no'),
(44, 'comment_registration', '0', 'yes'),
(45, 'html_type', 'text/html', 'yes'),
(46, 'use_trackback', '0', 'yes'),
(47, 'default_role', 'subscriber', 'yes'),
(48, 'db_version', '38590', 'yes'),
(49, 'uploads_use_yearmonth_folders', '1', 'yes'),
(50, 'upload_path', '', 'yes'),
(51, 'blog_public', '0', 'yes'),
(52, 'default_link_category', '2', 'yes'),
(53, 'show_on_front', 'page', 'yes'),
(54, 'tag_base', '', 'yes'),
(55, 'show_avatars', '1', 'yes'),
(56, 'avatar_rating', 'G', 'yes'),
(57, 'upload_url_path', '', 'yes'),
(58, 'thumbnail_size_w', '150', 'yes'),
(59, 'thumbnail_size_h', '150', 'yes'),
(60, 'thumbnail_crop', '1', 'yes'),
(61, 'medium_size_w', '300', 'yes'),
(62, 'medium_size_h', '300', 'yes'),
(63, 'avatar_default', 'mystery', 'yes'),
(64, 'large_size_w', '1024', 'yes'),
(65, 'large_size_h', '1024', 'yes'),
(66, 'image_default_link_type', 'none', 'yes'),
(67, 'image_default_size', '', 'yes'),
(68, 'image_default_align', '', 'yes'),
(69, 'close_comments_for_old_posts', '0', 'yes'),
(70, 'close_comments_days_old', '14', 'yes'),
(71, 'thread_comments', '1', 'yes'),
(72, 'thread_comments_depth', '5', 'yes'),
(73, 'page_comments', '0', 'yes'),
(74, 'comments_per_page', '50', 'yes'),
(75, 'default_comments_page', 'newest', 'yes'),
(76, 'comment_order', 'asc', 'yes'),
(77, 'sticky_posts', 'a:0:{}', 'yes'),
(78, 'widget_categories', 'a:2:{i:2;a:4:{s:5:"title";s:0:"";s:5:"count";i:0;s:12:"hierarchical";i:0;s:8:"dropdown";i:0;}s:12:"_multiwidget";i:1;}', 'yes'),
(79, 'widget_text', 'a:0:{}', 'yes'),
(80, 'widget_rss', 'a:0:{}', 'yes'),
(81, 'uninstall_plugins', 'a:0:{}', 'no'),
(82, 'timezone_string', '', 'yes'),
(83, 'page_for_posts', '0', 'yes'),
(84, 'page_on_front', '23', 'yes'),
(85, 'default_post_format', '0', 'yes'),
(86, 'link_manager_enabled', '0', 'yes'),
(87, 'finished_splitting_shared_terms', '1', 'yes'),
(88, 'site_icon', '0', 'yes'),
(89, 'medium_large_size_w', '768', 'yes'),
(90, 'medium_large_size_h', '0', 'yes'),
(91, 'initial_db_version', '38590', 'yes'),
(92, 'wp_user_roles', 'a:5:{s:13:"administrator";a:2:{s:4:"name";s:13:"Administrator";s:12:"capabilities";a:61:{s:13:"switch_themes";b:1;s:11:"edit_themes";b:1;s:16:"activate_plugins";b:1;s:12:"edit_plugins";b:1;s:10:"edit_users";b:1;s:10:"edit_files";b:1;s:14:"manage_options";b:1;s:17:"moderate_comments";b:1;s:17:"manage_categories";b:1;s:12:"manage_links";b:1;s:12:"upload_files";b:1;s:6:"import";b:1;s:15:"unfiltered_html";b:1;s:10:"edit_posts";b:1;s:17:"edit_others_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:10:"edit_pages";b:1;s:4:"read";b:1;s:8:"level_10";b:1;s:7:"level_9";b:1;s:7:"level_8";b:1;s:7:"level_7";b:1;s:7:"level_6";b:1;s:7:"level_5";b:1;s:7:"level_4";b:1;s:7:"level_3";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:17:"edit_others_pages";b:1;s:20:"edit_published_pages";b:1;s:13:"publish_pages";b:1;s:12:"delete_pages";b:1;s:19:"delete_others_pages";b:1;s:22:"delete_published_pages";b:1;s:12:"delete_posts";b:1;s:19:"delete_others_posts";b:1;s:22:"delete_published_posts";b:1;s:20:"delete_private_posts";b:1;s:18:"edit_private_posts";b:1;s:18:"read_private_posts";b:1;s:20:"delete_private_pages";b:1;s:18:"edit_private_pages";b:1;s:18:"read_private_pages";b:1;s:12:"delete_users";b:1;s:12:"create_users";b:1;s:17:"unfiltered_upload";b:1;s:14:"edit_dashboard";b:1;s:14:"update_plugins";b:1;s:14:"delete_plugins";b:1;s:15:"install_plugins";b:1;s:13:"update_themes";b:1;s:14:"install_themes";b:1;s:11:"update_core";b:1;s:10:"list_users";b:1;s:12:"remove_users";b:1;s:13:"promote_users";b:1;s:18:"edit_theme_options";b:1;s:13:"delete_themes";b:1;s:6:"export";b:1;}}s:6:"editor";a:2:{s:4:"name";s:6:"Editor";s:12:"capabilities";a:34:{s:17:"moderate_comments";b:1;s:17:"manage_categories";b:1;s:12:"manage_links";b:1;s:12:"upload_files";b:1;s:15:"unfiltered_html";b:1;s:10:"edit_posts";b:1;s:17:"edit_others_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:10:"edit_pages";b:1;s:4:"read";b:1;s:7:"level_7";b:1;s:7:"level_6";b:1;s:7:"level_5";b:1;s:7:"level_4";b:1;s:7:"level_3";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:17:"edit_others_pages";b:1;s:20:"edit_published_pages";b:1;s:13:"publish_pages";b:1;s:12:"delete_pages";b:1;s:19:"delete_others_pages";b:1;s:22:"delete_published_pages";b:1;s:12:"delete_posts";b:1;s:19:"delete_others_posts";b:1;s:22:"delete_published_posts";b:1;s:20:"delete_private_posts";b:1;s:18:"edit_private_posts";b:1;s:18:"read_private_posts";b:1;s:20:"delete_private_pages";b:1;s:18:"edit_private_pages";b:1;s:18:"read_private_pages";b:1;}}s:6:"author";a:2:{s:4:"name";s:6:"Author";s:12:"capabilities";a:10:{s:12:"upload_files";b:1;s:10:"edit_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:4:"read";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:12:"delete_posts";b:1;s:22:"delete_published_posts";b:1;}}s:11:"contributor";a:2:{s:4:"name";s:11:"Contributor";s:12:"capabilities";a:5:{s:10:"edit_posts";b:1;s:4:"read";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:12:"delete_posts";b:1;}}s:10:"subscriber";a:2:{s:4:"name";s:10:"Subscriber";s:12:"capabilities";a:2:{s:4:"read";b:1;s:7:"level_0";b:1;}}}', 'yes'),
(93, 'fresh_site', '0', 'yes'),
(94, 'widget_search', 'a:2:{i:2;a:1:{s:5:"title";s:0:"";}s:12:"_multiwidget";i:1;}', 'yes'),
(95, 'widget_recent-posts', 'a:2:{i:2;a:2:{s:5:"title";s:0:"";s:6:"number";i:5;}s:12:"_multiwidget";i:1;}', 'yes'),
(96, 'widget_recent-comments', 'a:2:{i:2;a:2:{s:5:"title";s:0:"";s:6:"number";i:5;}s:12:"_multiwidget";i:1;}', 'yes'),
(97, 'widget_archives', 'a:2:{i:2;a:3:{s:5:"title";s:0:"";s:5:"count";i:0;s:8:"dropdown";i:0;}s:12:"_multiwidget";i:1;}', 'yes'),
(98, 'widget_meta', 'a:2:{i:2;a:1:{s:5:"title";s:0:"";}s:12:"_multiwidget";i:1;}', 'yes'),
(99, 'sidebars_widgets', 'a:2:{s:19:"wp_inactive_widgets";a:6:{i:0;s:8:"search-2";i:1;s:14:"recent-posts-2";i:2;s:17:"recent-comments-2";i:3;s:10:"archives-2";i:4;s:12:"categories-2";i:5;s:6:"meta-2";}s:13:"array_version";i:3;}', 'yes'),
(100, 'widget_pages', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes') ;
INSERT INTO `wp_options` ( `option_id`, `option_name`, `option_value`, `autoload`) VALUES
(101, 'widget_calendar', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(102, 'widget_media_audio', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(103, 'widget_media_image', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(104, 'widget_media_gallery', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(105, 'widget_media_video', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(106, 'nonce_key', '8].hd89x:v6]3c[lGQiXXh?K@|_u(!?z/t+t8h[(#shrjFgx#(?2p0oq<?.2J.lz', 'no'),
(107, 'nonce_salt', 'Hkf5FSjXR>(|16GC]Fq&$MKfT|&V7WYMKs<~5AMPDkJ5TK1.)Ss(|I};7jz]!teM', 'no'),
(108, 'widget_tag_cloud', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(109, 'widget_nav_menu', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(110, 'widget_custom_html', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(111, 'cron', 'a:5:{i:1547242716;a:1:{s:34:"wp_privacy_delete_old_export_files";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:6:"hourly";s:4:"args";a:0:{}s:8:"interval";i:3600;}}}i:1547278696;a:3:{s:16:"wp_version_check";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}s:17:"wp_update_plugins";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}s:16:"wp_update_themes";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}}i:1547312839;a:1:{s:30:"wp_scheduled_auto_draft_delete";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}}i:1547321921;a:2:{s:19:"wp_scheduled_delete";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}s:25:"delete_expired_transients";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}}s:7:"version";i:2;}', 'yes'),
(121, 'auto_core_update_notified', 'a:4:{s:4:"type";s:7:"success";s:5:"email";s:24:"admin@thisisblueline.com";s:7:"version";s:5:"4.9.9";s:9:"timestamp";i:1544720927;}', 'no'),
(123, 'auth_key', 'D_$2wODQEcT|LCz!fdGy[iZoU{l3WpKr&!CBLBhOOXv<-,MD:|+04r~GMWVvGj =', 'no'),
(124, 'auth_salt', 'c$jGD!U?HOF9Uq1?<YUj3@BZQ62x1 !*ul>0^u,p*{JZCxJ41f|3%m!EMo|pZ },', 'no'),
(125, 'logged_in_key', ' ej8W>jC<:hqM{IGZg@x^Ib|{mjZLFSKarQ6mpP<P]$=,uO6fJLig^ar.9!Z(T+b', 'no'),
(126, 'logged_in_salt', 'NHB}o^W9S:.tzq<?2W|ww*|X)sI3sf`Pkwh-hTAAmr!)L/}_Hw:E2b+!`-4zqWg)', 'no'),
(136, 'can_compress_scripts', '1', 'no'),
(145, 'recently_activated', 'a:1:{s:30:"advanced-custom-fields/acf.php";i:1547155027;}', 'yes'),
(167, 'theme_mods_twentyseventeen', 'a:1:{s:16:"sidebars_widgets";a:2:{s:4:"time";i:1544027891;s:4:"data";a:4:{s:19:"wp_inactive_widgets";a:0:{}s:9:"sidebar-1";a:6:{i:0;s:8:"search-2";i:1;s:14:"recent-posts-2";i:2;s:17:"recent-comments-2";i:3;s:10:"archives-2";i:4;s:12:"categories-2";i:5;s:6:"meta-2";}s:9:"sidebar-2";a:0:{}s:9:"sidebar-3";a:0:{}}}}', 'yes'),
(168, 'current_theme', 'Habitat for Humanity', 'yes'),
(169, 'theme_mods_habitat', 'a:3:{i:0;b:0;s:18:"nav_menu_locations";a:8:{s:11:"header-menu";i:2;s:12:"primary-menu";i:2;s:15:"header-top-menu";i:3;s:8:"top-menu";i:3;s:15:"footer-whoweare";i:5;s:16:"footer-volunteer";i:6;s:17:"footer-waystogive";i:7;s:12:"footer-apply";i:8;}s:18:"custom_css_post_id";i:-1;}', 'yes'),
(170, 'theme_switched', '', 'yes'),
(175, 'nav_menu_options', 'a:2:{i:0;b:0;s:8:"auto_add";a:0:{}}', 'yes'),
(348, 'category_children', 'a:0:{}', 'yes'),
(362, 'acf_version', '5.7.9', 'yes'),
(368, 'acf_pro_license', 'YToyOntzOjM6ImtleSI7czo3MjoiYjNKa1pYSmZhV1E5TVRBNU9UTTJmSFI1Y0dVOWNHVnljMjl1WVd4OFpHRjBaVDB5TURFM0xUQTNMVEEzSURFME9qRTBPakF4IjtzOjM6InVybCI7czoyOToiaHR0cDovL2xvY2FsaG9zdDo4ODg4L2hhYml0YXQiO30=', 'yes'),
(402, 'wpmdb_usage', 'a:2:{s:6:"action";s:8:"savefile";s:4:"time";i:1547240814;}', 'no') ;

#
# End of data contents of table `wp_options`
# --------------------------------------------------------



#
# Delete any existing table `wp_postmeta`
#

DROP TABLE IF EXISTS `wp_postmeta`;


#
# Table structure of table `wp_postmeta`
#

CREATE TABLE `wp_postmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `post_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_520_ci,
  PRIMARY KEY (`meta_id`),
  KEY `post_id` (`post_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB AUTO_INCREMENT=512 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_postmeta`
#
INSERT INTO `wp_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(1, 2, '_wp_page_template', 'page-standard.php'),
(2, 2, '_edit_lock', '1544029495:1'),
(3, 2, '_edit_last', '1'),
(4, 5, '_edit_last', '1'),
(5, 5, '_wp_page_template', 'page-standard.php'),
(6, 5, '_edit_lock', '1544122469:1'),
(7, 7, '_menu_item_type', 'custom'),
(8, 7, '_menu_item_menu_item_parent', '0'),
(9, 7, '_menu_item_object_id', '7'),
(10, 7, '_menu_item_object', 'custom'),
(11, 7, '_menu_item_target', ''),
(12, 7, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(13, 7, '_menu_item_xfn', ''),
(14, 7, '_menu_item_url', 'http://localhost:8888/habitat/'),
(43, 11, '_menu_item_type', 'custom'),
(44, 11, '_menu_item_menu_item_parent', '0'),
(45, 11, '_menu_item_object_id', '11'),
(46, 11, '_menu_item_object', 'custom'),
(47, 11, '_menu_item_target', ''),
(48, 11, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(49, 11, '_menu_item_xfn', ''),
(50, 11, '_menu_item_url', '#'),
(51, 20, '_menu_item_type', 'custom'),
(52, 20, '_menu_item_menu_item_parent', '0'),
(53, 20, '_menu_item_object_id', '20'),
(54, 20, '_menu_item_object', 'custom'),
(55, 20, '_menu_item_target', ''),
(56, 20, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(57, 20, '_menu_item_xfn', ''),
(58, 20, '_menu_item_url', '#'),
(60, 21, '_menu_item_type', 'custom'),
(61, 21, '_menu_item_menu_item_parent', '0'),
(62, 21, '_menu_item_object_id', '21'),
(63, 21, '_menu_item_object', 'custom'),
(64, 21, '_menu_item_target', ''),
(65, 21, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(66, 21, '_menu_item_xfn', ''),
(67, 21, '_menu_item_url', '#'),
(69, 22, '_menu_item_type', 'custom'),
(70, 22, '_menu_item_menu_item_parent', '0'),
(71, 22, '_menu_item_object_id', '22'),
(72, 22, '_menu_item_object', 'custom'),
(73, 22, '_menu_item_target', ''),
(74, 22, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(75, 22, '_menu_item_xfn', ''),
(76, 22, '_menu_item_url', '#'),
(77, 23, '_edit_last', '1'),
(78, 23, '_wp_page_template', 'page-home.php'),
(79, 23, '_edit_lock', '1547232946:1'),
(80, 5, '_wp_trash_meta_status', 'publish'),
(81, 5, '_wp_trash_meta_time', '1546962776'),
(82, 5, '_wp_desired_post_slug', 'test'),
(86, 2, '_wp_trash_meta_status', 'publish'),
(87, 2, '_wp_trash_meta_time', '1546962786'),
(88, 2, '_wp_desired_post_slug', 'sample-page'),
(89, 26, '_edit_last', '1'),
(90, 26, '_wp_page_template', 'page-apply.php'),
(91, 26, '_edit_lock', '1547049991:1'),
(92, 28, '_edit_last', '1'),
(93, 28, '_edit_lock', '1547049991:1'),
(94, 28, '_wp_page_template', 'page-volunteer.php'),
(95, 29, '_edit_last', '1'),
(96, 29, '_edit_lock', '1547053372:1'),
(97, 29, '_wp_page_template', 'page-who-are-we.php'),
(98, 32, '_edit_last', '1'),
(99, 32, '_wp_page_template', 'page-standard.php'),
(100, 32, '_edit_lock', '1547132808:1'),
(101, 35, '_menu_item_type', 'post_type'),
(102, 35, '_menu_item_menu_item_parent', '0'),
(103, 35, '_menu_item_object_id', '29'),
(104, 35, '_menu_item_object', 'page'),
(105, 35, '_menu_item_target', ''),
(106, 35, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(107, 35, '_menu_item_xfn', ''),
(108, 35, '_menu_item_url', ''),
(110, 36, '_menu_item_type', 'post_type'),
(111, 36, '_menu_item_menu_item_parent', '0'),
(112, 36, '_menu_item_object_id', '28'),
(113, 36, '_menu_item_object', 'page'),
(114, 36, '_menu_item_target', ''),
(115, 36, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(116, 36, '_menu_item_xfn', ''),
(117, 36, '_menu_item_url', ''),
(119, 37, '_menu_item_type', 'post_type'),
(120, 37, '_menu_item_menu_item_parent', '0'),
(121, 37, '_menu_item_object_id', '26'),
(122, 37, '_menu_item_object', 'page'),
(123, 37, '_menu_item_target', ''),
(124, 37, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(125, 37, '_menu_item_xfn', ''),
(126, 37, '_menu_item_url', ''),
(128, 38, '_edit_last', '1'),
(129, 38, '_edit_lock', '1547049991:1'),
(130, 38, '_wp_page_template', 'default'),
(131, 40, '_menu_item_type', 'post_type'),
(132, 40, '_menu_item_menu_item_parent', '0'),
(133, 40, '_menu_item_object_id', '38'),
(134, 40, '_menu_item_object', 'page'),
(135, 40, '_menu_item_target', ''),
(136, 40, '_menu_item_classes', 'a:1:{i:0;s:0:"";}') ;
INSERT INTO `wp_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(137, 40, '_menu_item_xfn', ''),
(138, 40, '_menu_item_url', ''),
(139, 42, '_edit_last', '1'),
(140, 42, '_edit_lock', '1547132775:1'),
(142, 44, '_edit_last', '1'),
(143, 44, '_wp_page_template', 'default'),
(144, 44, '_edit_lock', '1547132774:1'),
(145, 46, '_edit_last', '1'),
(146, 46, '_wp_page_template', 'default'),
(147, 46, '_edit_lock', '1547132763:1'),
(148, 48, '_edit_last', '1'),
(149, 48, '_wp_page_template', 'default'),
(150, 48, '_edit_lock', '1547132773:1'),
(155, 52, '_edit_last', '1'),
(156, 52, '_edit_lock', '1547230965:1'),
(157, 54, '_wp_attached_file', '2019/01/Bloom-Frame-Up-Day-69.jpg'),
(158, 54, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:2768;s:6:"height";i:1848;s:4:"file";s:33:"2019/01/Bloom-Frame-Up-Day-69.jpg";s:5:"sizes";a:4:{s:9:"thumbnail";a:4:{s:4:"file";s:33:"Bloom-Frame-Up-Day-69-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:33:"Bloom-Frame-Up-Day-69-300x200.jpg";s:5:"width";i:300;s:6:"height";i:200;s:9:"mime-type";s:10:"image/jpeg";}s:12:"medium_large";a:4:{s:4:"file";s:33:"Bloom-Frame-Up-Day-69-768x513.jpg";s:5:"width";i:768;s:6:"height";i:513;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:34:"Bloom-Frame-Up-Day-69-1024x684.jpg";s:5:"width";i:1024;s:6:"height";i:684;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(159, 23, 'featured_banner', '54'),
(160, 23, '_featured_banner', 'field_5c37b8f643fd0'),
(161, 55, 'featured_banner', '54'),
(162, 55, '_featured_banner', 'field_5c37b8f643fd0'),
(163, 23, 'featured_banner_text', 'Last year you helped us divert 1.1 million pounds to land fills.'),
(164, 23, '_featured_banner_text', 'field_5c37bf64d648d'),
(165, 57, 'featured_banner', '54'),
(166, 57, '_featured_banner', 'field_5c37b8f643fd0'),
(167, 57, 'featured_banner_text', 'Last year you helped us divert 1.1 million pounds to land fills.'),
(168, 57, '_featured_banner_text', 'field_5c37bf64d648d'),
(169, 1, '_wp_trash_meta_status', 'publish'),
(170, 1, '_wp_trash_meta_time', '1547224513'),
(171, 1, '_wp_desired_post_slug', 'hello-world'),
(172, 1, '_wp_trash_meta_comments_status', 'a:1:{i:1;s:1:"1";}'),
(173, 23, 'homeowner_text', 'Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Lorem ipsum dolor sit amet, consectetuer.'),
(174, 23, '_homeowner_text', 'field_5c38def41c243'),
(175, 23, 'volunteer_text', 'Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Lorem ipsum dolor.'),
(176, 23, '_volunteer_text', 'field_5c38def41c253'),
(177, 23, 'restore_text', 'Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Lorem ipsum dolor sit amet, consectetuer adipiscing elit.'),
(178, 23, '_restore_text', 'field_5c38def41c262'),
(179, 63, 'featured_banner', '54'),
(180, 63, '_featured_banner', 'field_5c37b8f643fd0'),
(181, 63, 'featured_banner_text', 'Last year you helped us divert 1.1 million pounds to land fills.'),
(182, 63, '_featured_banner_text', 'field_5c37bf64d648d'),
(183, 63, 'homeowner_text', 'Lorem ipsum dolor sit amet, consectetuer adipiscing elit.'),
(184, 63, '_homeowner_text', 'field_5c38c91643af5'),
(185, 63, 'volunteer_text', 'Lorem ipsum dolor sit amet, consectetuer adipiscing elit.'),
(186, 63, '_volunteer_text', 'field_5c38c9e05168b'),
(187, 63, 'restore_text', 'Lorem ipsum dolor sit amet, consectetuer adipiscing elit.'),
(188, 63, '_restore_text', 'field_5c38c9f05168c'),
(189, 64, 'featured_banner', '54'),
(190, 64, '_featured_banner', 'field_5c37b8f643fd0'),
(191, 64, 'featured_banner_text', 'Last year you helped us divert 1.1 million pounds to land fills.'),
(192, 64, '_featured_banner_text', 'field_5c37bf64d648d'),
(193, 64, 'homeowner_text', 'Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Lorem ipsum dolor sit amet, consectetuer.'),
(194, 64, '_homeowner_text', 'field_5c38c91643af5'),
(195, 64, 'volunteer_text', 'Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Lorem ipsum dolor.'),
(196, 64, '_volunteer_text', 'field_5c38c9e05168b'),
(197, 64, 'restore_text', 'Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Lorem ipsum dolor sit amet, consectetuer adipiscing elit.'),
(198, 64, '_restore_text', 'field_5c38c9f05168c'),
(199, 68, '_edit_lock', '1547230966:1'),
(200, 68, '_edit_last', '1'),
(201, 76, '_edit_lock', '1547232587:1'),
(202, 76, '_edit_last', '1'),
(203, 23, 'mission_statement', 'Habitat for Humanity of Monroe County’s mission is to eliminate poverty housing by building decent, affordable homes in partnership with qualifying families.'),
(204, 23, '_mission_statement', 'field_5c38df69cf456'),
(205, 23, 'mission_statement_subtext', 'The only thing Habitat gives away is an opportunity.'),
(206, 23, '_mission_statement_subtext', 'field_5c38df95912ef'),
(207, 81, 'featured_banner', '54'),
(208, 81, '_featured_banner', 'field_5c37b8f643fd0'),
(209, 81, 'featured_banner_text', 'Last year you helped us divert 1.1 million pounds to land fills.'),
(210, 81, '_featured_banner_text', 'field_5c37bf64d648d'),
(211, 81, 'homeowner_text', 'Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Lorem ipsum dolor sit amet, consectetuer.'),
(212, 81, '_homeowner_text', 'field_5c38def41c243'),
(213, 81, 'volunteer_text', 'Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Lorem ipsum dolor.'),
(214, 81, '_volunteer_text', 'field_5c38def41c253'),
(215, 81, 'restore_text', 'Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Lorem ipsum dolor sit amet, consectetuer adipiscing elit.'),
(216, 81, '_restore_text', 'field_5c38def41c262'),
(217, 81, 'mission_statement', 'Habitat for Humanity of Monroe County’s mission is to eliminate poverty housing by building decent, affordable homes in partnership with qualifying families.'),
(218, 81, '_mission_statement', 'field_5c38df69cf456'),
(219, 81, 'mission_statement_subtext', 'Habitat for Humanity of Monroe County’s mission is to eliminate poverty housing by building decent, affordable homes in partnership with qualifying families.'),
(220, 81, '_mission_statement_subtext', 'field_5c38df95912ef'),
(221, 82, 'featured_banner', '54'),
(222, 82, '_featured_banner', 'field_5c37b8f643fd0'),
(223, 82, 'featured_banner_text', 'Last year you helped us divert 1.1 million pounds to land fills.'),
(224, 82, '_featured_banner_text', 'field_5c37bf64d648d'),
(225, 82, 'homeowner_text', 'Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Lorem ipsum dolor sit amet, consectetuer.'),
(226, 82, '_homeowner_text', 'field_5c38def41c243'),
(227, 82, 'volunteer_text', 'Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Lorem ipsum dolor.'),
(228, 82, '_volunteer_text', 'field_5c38def41c253'),
(229, 82, 'restore_text', 'Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Lorem ipsum dolor sit amet, consectetuer adipiscing elit.'),
(230, 82, '_restore_text', 'field_5c38def41c262'),
(231, 82, 'mission_statement', 'Habitat for Humanity of Monroe County’s mission is to eliminate poverty housing by building decent, affordable homes in partnership with qualifying families.'),
(232, 82, '_mission_statement', 'field_5c38df69cf456'),
(233, 82, 'mission_statement_subtext', 'The only thing Habitat gives away is an opportunity.'),
(234, 82, '_mission_statement_subtext', 'field_5c38df95912ef'),
(235, 83, '_edit_last', '1'),
(236, 83, '_edit_lock', '1547232723:1'),
(237, 23, 'donate_button_text', 'DONATE TODAY'),
(238, 23, '_donate_button_text', 'field_5c38e5e597eb3'),
(239, 23, 'donate_button_url', 'https://google.com'),
(240, 23, '_donate_button_url', 'field_5c38e5fb84046'),
(241, 86, 'featured_banner', '54') ;
INSERT INTO `wp_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(242, 86, '_featured_banner', 'field_5c37b8f643fd0'),
(243, 86, 'featured_banner_text', 'Last year you helped us divert 1.1 million pounds to land fills.'),
(244, 86, '_featured_banner_text', 'field_5c37bf64d648d'),
(245, 86, 'homeowner_text', 'Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Lorem ipsum dolor sit amet, consectetuer.'),
(246, 86, '_homeowner_text', 'field_5c38def41c243'),
(247, 86, 'volunteer_text', 'Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Lorem ipsum dolor.'),
(248, 86, '_volunteer_text', 'field_5c38def41c253'),
(249, 86, 'restore_text', 'Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Lorem ipsum dolor sit amet, consectetuer adipiscing elit.'),
(250, 86, '_restore_text', 'field_5c38def41c262'),
(251, 86, 'mission_statement', 'Habitat for Humanity of Monroe County’s mission is to eliminate poverty housing by building decent, affordable homes in partnership with qualifying families.'),
(252, 86, '_mission_statement', 'field_5c38df69cf456'),
(253, 86, 'mission_statement_subtext', 'The only thing Habitat gives away is an opportunity.'),
(254, 86, '_mission_statement_subtext', 'field_5c38df95912ef'),
(255, 86, 'donate_button_text', 'DONATE TODAY'),
(256, 86, '_donate_button_text', 'field_5c38e5e597eb3'),
(257, 86, 'donate_button_url', 'https://google.com'),
(258, 86, '_donate_button_url', 'field_5c38e5fb84046'),
(259, 88, '_edit_lock', '1547232946:1'),
(260, 88, '_edit_last', '1'),
(261, 23, 'families_button_text', 'MEET ALL OF OUR FAMILIES'),
(262, 23, '_families_button_text', 'field_5c38e66a244c8'),
(263, 23, 'families_button_url', 'https://google.com'),
(264, 23, '_families_button_url', 'field_5c38e66a244dd'),
(265, 91, 'featured_banner', '54'),
(266, 91, '_featured_banner', 'field_5c37b8f643fd0'),
(267, 91, 'featured_banner_text', 'Last year you helped us divert 1.1 million pounds to land fills.'),
(268, 91, '_featured_banner_text', 'field_5c37bf64d648d'),
(269, 91, 'homeowner_text', 'Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Lorem ipsum dolor sit amet, consectetuer.'),
(270, 91, '_homeowner_text', 'field_5c38def41c243'),
(271, 91, 'volunteer_text', 'Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Lorem ipsum dolor.'),
(272, 91, '_volunteer_text', 'field_5c38def41c253'),
(273, 91, 'restore_text', 'Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Lorem ipsum dolor sit amet, consectetuer adipiscing elit.'),
(274, 91, '_restore_text', 'field_5c38def41c262'),
(275, 91, 'mission_statement', 'Habitat for Humanity of Monroe County’s mission is to eliminate poverty housing by building decent, affordable homes in partnership with qualifying families.'),
(276, 91, '_mission_statement', 'field_5c38df69cf456'),
(277, 91, 'mission_statement_subtext', 'The only thing Habitat gives away is an opportunity.'),
(278, 91, '_mission_statement_subtext', 'field_5c38df95912ef'),
(279, 91, 'donate_button_text', 'DONATE TODAY'),
(280, 91, '_donate_button_text', 'field_5c38e5e597eb3'),
(281, 91, 'donate_button_url', 'https://google.com'),
(282, 91, '_donate_button_url', 'field_5c38e5fb84046'),
(283, 91, 'families_button_text', 'MEET ALL OF OUR FAMILIES'),
(284, 91, '_families_button_text', 'field_5c38e66a244c8'),
(285, 91, 'families_button_url', 'https://google.com'),
(286, 91, '_families_button_url', 'field_5c38e66a244dd'),
(287, 92, '_menu_item_type', 'post_type'),
(288, 92, '_menu_item_menu_item_parent', '0'),
(289, 92, '_menu_item_object_id', '48'),
(290, 92, '_menu_item_object', 'page'),
(291, 92, '_menu_item_target', ''),
(292, 92, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(293, 92, '_menu_item_xfn', ''),
(294, 92, '_menu_item_url', ''),
(296, 93, '_menu_item_type', 'post_type'),
(297, 93, '_menu_item_menu_item_parent', '0'),
(298, 93, '_menu_item_object_id', '46'),
(299, 93, '_menu_item_object', 'page'),
(300, 93, '_menu_item_target', ''),
(301, 93, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(302, 93, '_menu_item_xfn', ''),
(303, 93, '_menu_item_url', ''),
(305, 94, '_menu_item_type', 'post_type'),
(306, 94, '_menu_item_menu_item_parent', '0'),
(307, 94, '_menu_item_object_id', '44'),
(308, 94, '_menu_item_object', 'page'),
(309, 94, '_menu_item_target', ''),
(310, 94, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(311, 94, '_menu_item_xfn', ''),
(312, 94, '_menu_item_url', ''),
(314, 95, '_menu_item_type', 'post_type'),
(315, 95, '_menu_item_menu_item_parent', '0'),
(316, 95, '_menu_item_object_id', '38'),
(317, 95, '_menu_item_object', 'page'),
(318, 95, '_menu_item_target', ''),
(319, 95, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(320, 95, '_menu_item_xfn', ''),
(321, 95, '_menu_item_url', ''),
(323, 96, '_menu_item_type', 'post_type'),
(324, 96, '_menu_item_menu_item_parent', '0'),
(325, 96, '_menu_item_object_id', '32'),
(326, 96, '_menu_item_object', 'page'),
(327, 96, '_menu_item_target', ''),
(328, 96, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(329, 96, '_menu_item_xfn', ''),
(330, 96, '_menu_item_url', ''),
(332, 97, '_menu_item_type', 'post_type'),
(333, 97, '_menu_item_menu_item_parent', '0'),
(334, 97, '_menu_item_object_id', '29'),
(335, 97, '_menu_item_object', 'page'),
(336, 97, '_menu_item_target', ''),
(337, 97, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(338, 97, '_menu_item_xfn', ''),
(339, 97, '_menu_item_url', ''),
(341, 98, '_menu_item_type', 'post_type'),
(342, 98, '_menu_item_menu_item_parent', '0'),
(343, 98, '_menu_item_object_id', '28'),
(344, 98, '_menu_item_object', 'page'),
(345, 98, '_menu_item_target', ''),
(346, 98, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(347, 98, '_menu_item_xfn', '') ;
INSERT INTO `wp_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(348, 98, '_menu_item_url', ''),
(350, 99, '_menu_item_type', 'post_type'),
(351, 99, '_menu_item_menu_item_parent', '0'),
(352, 99, '_menu_item_object_id', '38'),
(353, 99, '_menu_item_object', 'page'),
(354, 99, '_menu_item_target', ''),
(355, 99, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(356, 99, '_menu_item_xfn', ''),
(357, 99, '_menu_item_url', ''),
(359, 100, '_menu_item_type', 'post_type'),
(360, 100, '_menu_item_menu_item_parent', '0'),
(361, 100, '_menu_item_object_id', '32'),
(362, 100, '_menu_item_object', 'page'),
(363, 100, '_menu_item_target', ''),
(364, 100, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(365, 100, '_menu_item_xfn', ''),
(366, 100, '_menu_item_url', ''),
(368, 101, '_menu_item_type', 'post_type'),
(369, 101, '_menu_item_menu_item_parent', '0'),
(370, 101, '_menu_item_object_id', '29'),
(371, 101, '_menu_item_object', 'page'),
(372, 101, '_menu_item_target', ''),
(373, 101, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(374, 101, '_menu_item_xfn', ''),
(375, 101, '_menu_item_url', ''),
(377, 102, '_menu_item_type', 'post_type'),
(378, 102, '_menu_item_menu_item_parent', '0'),
(379, 102, '_menu_item_object_id', '28'),
(380, 102, '_menu_item_object', 'page'),
(381, 102, '_menu_item_target', ''),
(382, 102, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(383, 102, '_menu_item_xfn', ''),
(384, 102, '_menu_item_url', ''),
(386, 103, '_menu_item_type', 'post_type'),
(387, 103, '_menu_item_menu_item_parent', '0'),
(388, 103, '_menu_item_object_id', '48'),
(389, 103, '_menu_item_object', 'page'),
(390, 103, '_menu_item_target', ''),
(391, 103, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(392, 103, '_menu_item_xfn', ''),
(393, 103, '_menu_item_url', ''),
(395, 104, '_menu_item_type', 'post_type'),
(396, 104, '_menu_item_menu_item_parent', '0'),
(397, 104, '_menu_item_object_id', '46'),
(398, 104, '_menu_item_object', 'page'),
(399, 104, '_menu_item_target', ''),
(400, 104, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(401, 104, '_menu_item_xfn', ''),
(402, 104, '_menu_item_url', ''),
(404, 105, '_menu_item_type', 'post_type'),
(405, 105, '_menu_item_menu_item_parent', '0'),
(406, 105, '_menu_item_object_id', '38'),
(407, 105, '_menu_item_object', 'page'),
(408, 105, '_menu_item_target', ''),
(409, 105, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(410, 105, '_menu_item_xfn', ''),
(411, 105, '_menu_item_url', ''),
(413, 106, '_menu_item_type', 'post_type'),
(414, 106, '_menu_item_menu_item_parent', '0'),
(415, 106, '_menu_item_object_id', '32'),
(416, 106, '_menu_item_object', 'page'),
(417, 106, '_menu_item_target', ''),
(418, 106, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(419, 106, '_menu_item_xfn', ''),
(420, 106, '_menu_item_url', ''),
(422, 107, '_menu_item_type', 'post_type'),
(423, 107, '_menu_item_menu_item_parent', '0'),
(424, 107, '_menu_item_object_id', '29'),
(425, 107, '_menu_item_object', 'page'),
(426, 107, '_menu_item_target', ''),
(427, 107, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(428, 107, '_menu_item_xfn', ''),
(429, 107, '_menu_item_url', ''),
(431, 108, '_menu_item_type', 'post_type'),
(432, 108, '_menu_item_menu_item_parent', '0'),
(433, 108, '_menu_item_object_id', '28'),
(434, 108, '_menu_item_object', 'page'),
(435, 108, '_menu_item_target', ''),
(436, 108, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(437, 108, '_menu_item_xfn', ''),
(438, 108, '_menu_item_url', ''),
(440, 109, '_menu_item_type', 'post_type'),
(441, 109, '_menu_item_menu_item_parent', '0'),
(442, 109, '_menu_item_object_id', '26'),
(443, 109, '_menu_item_object', 'page'),
(444, 109, '_menu_item_target', ''),
(445, 109, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(446, 109, '_menu_item_xfn', ''),
(447, 109, '_menu_item_url', ''),
(449, 110, '_menu_item_type', 'post_type'),
(450, 110, '_menu_item_menu_item_parent', '0'),
(451, 110, '_menu_item_object_id', '46'),
(452, 110, '_menu_item_object', 'page'),
(453, 110, '_menu_item_target', ''),
(454, 110, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(455, 110, '_menu_item_xfn', ''),
(456, 110, '_menu_item_url', ''),
(458, 111, '_menu_item_type', 'post_type'),
(459, 111, '_menu_item_menu_item_parent', '0'),
(460, 111, '_menu_item_object_id', '44') ;
INSERT INTO `wp_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(461, 111, '_menu_item_object', 'page'),
(462, 111, '_menu_item_target', ''),
(463, 111, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(464, 111, '_menu_item_xfn', ''),
(465, 111, '_menu_item_url', ''),
(467, 112, '_menu_item_type', 'post_type'),
(468, 112, '_menu_item_menu_item_parent', '0'),
(469, 112, '_menu_item_object_id', '38'),
(470, 112, '_menu_item_object', 'page'),
(471, 112, '_menu_item_target', ''),
(472, 112, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(473, 112, '_menu_item_xfn', ''),
(474, 112, '_menu_item_url', ''),
(476, 113, '_menu_item_type', 'post_type'),
(477, 113, '_menu_item_menu_item_parent', '0'),
(478, 113, '_menu_item_object_id', '32'),
(479, 113, '_menu_item_object', 'page'),
(480, 113, '_menu_item_target', ''),
(481, 113, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(482, 113, '_menu_item_xfn', ''),
(483, 113, '_menu_item_url', ''),
(485, 114, '_menu_item_type', 'post_type'),
(486, 114, '_menu_item_menu_item_parent', '0'),
(487, 114, '_menu_item_object_id', '29'),
(488, 114, '_menu_item_object', 'page'),
(489, 114, '_menu_item_target', ''),
(490, 114, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(491, 114, '_menu_item_xfn', ''),
(492, 114, '_menu_item_url', ''),
(494, 115, '_menu_item_type', 'post_type'),
(495, 115, '_menu_item_menu_item_parent', '0'),
(496, 115, '_menu_item_object_id', '28'),
(497, 115, '_menu_item_object', 'page'),
(498, 115, '_menu_item_target', ''),
(499, 115, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(500, 115, '_menu_item_xfn', ''),
(501, 115, '_menu_item_url', ''),
(503, 116, '_menu_item_type', 'post_type'),
(504, 116, '_menu_item_menu_item_parent', '0'),
(505, 116, '_menu_item_object_id', '26'),
(506, 116, '_menu_item_object', 'page'),
(507, 116, '_menu_item_target', ''),
(508, 116, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(509, 116, '_menu_item_xfn', ''),
(510, 116, '_menu_item_url', '') ;

#
# End of data contents of table `wp_postmeta`
# --------------------------------------------------------



#
# Delete any existing table `wp_posts`
#

DROP TABLE IF EXISTS `wp_posts`;


#
# Table structure of table `wp_posts`
#

CREATE TABLE `wp_posts` (
  `ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `post_author` bigint(20) unsigned NOT NULL DEFAULT '0',
  `post_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_title` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_excerpt` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_status` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'publish',
  `comment_status` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'open',
  `ping_status` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'open',
  `post_password` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `post_name` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `to_ping` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `pinged` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_modified_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content_filtered` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `guid` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `menu_order` int(11) NOT NULL DEFAULT '0',
  `post_type` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'post',
  `post_mime_type` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_count` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`ID`),
  KEY `post_name` (`post_name`(191)),
  KEY `type_status_date` (`post_type`,`post_status`,`post_date`,`ID`),
  KEY `post_parent` (`post_parent`),
  KEY `post_author` (`post_author`)
) ENGINE=InnoDB AUTO_INCREMENT=117 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_posts`
#
INSERT INTO `wp_posts` ( `ID`, `post_author`, `post_date`, `post_date_gmt`, `post_content`, `post_title`, `post_excerpt`, `post_status`, `comment_status`, `ping_status`, `post_password`, `post_name`, `to_ping`, `pinged`, `post_modified`, `post_modified_gmt`, `post_content_filtered`, `post_parent`, `guid`, `menu_order`, `post_type`, `post_mime_type`, `comment_count`) VALUES
(1, 1, '2018-11-27 19:38:15', '2018-11-27 19:38:15', 'Welcome to WordPress. This is your first post. Edit or delete it, then start writing!', 'Hello world!', '', 'trash', 'open', 'open', '', 'hello-world__trashed', '', '', '2019-01-11 16:35:13', '2019-01-11 16:35:13', '', 0, 'http://localhost:8888/habitat/?p=1', 0, 'post', '', 1),
(2, 1, '2018-11-27 19:38:15', '2018-11-27 19:38:15', 'This is an example page. It\'s different from a blog post because it will stay in one place and will show up in your site navigation (in most themes). Most people start with an About page that introduces them to potential site visitors. It might say something like this:\r\n<blockquote>Hi there! I\'m a bike messenger by day, aspiring actor by night, and this is my website. I live in Los Angeles, have a great dog named Jack, and I like piña coladas. (And gettin\' caught in the rain.)</blockquote>\r\n...or something like this:\r\n<blockquote>The XYZ Doohickey Company was founded in 1971, and has been providing quality doohickeys to the public ever since. Located in Gotham City, XYZ employs over 2,000 people and does all kinds of awesome things for the Gotham community.</blockquote>\r\nAs a new WordPress user, you should go to <a href="http://localhost:8888/habitat/wp-admin/">your dashboard</a> to delete this page and create new pages for your content. Have fun!', 'Sample Page', '', 'trash', 'closed', 'open', '', 'sample-page__trashed', '', '', '2019-01-08 15:53:06', '2019-01-08 15:53:06', '', 0, 'http://localhost:8888/habitat/?page_id=2', 0, 'page', '', 0),
(4, 1, '2018-12-05 16:49:21', '2018-12-05 16:49:21', 'This is an example page. It\'s different from a blog post because it will stay in one place and will show up in your site navigation (in most themes). Most people start with an About page that introduces them to potential site visitors. It might say something like this:\r\n<blockquote>Hi there! I\'m a bike messenger by day, aspiring actor by night, and this is my website. I live in Los Angeles, have a great dog named Jack, and I like piña coladas. (And gettin\' caught in the rain.)</blockquote>\r\n...or something like this:\r\n<blockquote>The XYZ Doohickey Company was founded in 1971, and has been providing quality doohickeys to the public ever since. Located in Gotham City, XYZ employs over 2,000 people and does all kinds of awesome things for the Gotham community.</blockquote>\r\nAs a new WordPress user, you should go to <a href="http://localhost:8888/habitat/wp-admin/">your dashboard</a> to delete this page and create new pages for your content. Have fun!', 'Sample Page', '', 'inherit', 'closed', 'closed', '', '2-revision-v1', '', '', '2018-12-05 16:49:21', '2018-12-05 16:49:21', '', 2, 'http://localhost:8888/habitat/2018/12/05/2-revision-v1/', 0, 'revision', '', 0),
(5, 1, '2018-12-05 17:07:44', '2018-12-05 17:07:44', '<h1>Heading 1</h1>\r\nAn example of <strong>bold text</strong> followed by <em>italics style</em>, and then an un-ordered list:\r\n<ul>\r\n 	<li>apples</li>\r\n 	<li>bananas</li>\r\n 	<li>crepes</li>\r\n</ul>\r\nLorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolorLorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ippsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum Lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum ', 'Test', '', 'trash', 'closed', 'closed', '', 'test__trashed', '', '', '2019-01-08 15:52:56', '2019-01-08 15:52:56', '', 0, 'http://localhost:8888/habitat/?page_id=5', 0, 'page', '', 0),
(6, 1, '2018-12-05 17:07:44', '2018-12-05 17:07:44', 'Lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor', 'Test', '', 'inherit', 'closed', 'closed', '', '5-revision-v1', '', '', '2018-12-05 17:07:44', '2018-12-05 17:07:44', '', 5, 'http://localhost:8888/habitat/2018/12/05/5-revision-v1/', 0, 'revision', '', 0),
(7, 1, '2018-12-05 17:22:27', '2018-12-05 17:22:27', '', 'Home', '', 'publish', 'closed', 'closed', '', 'home', '', '', '2019-01-09 16:08:48', '2019-01-09 16:08:48', '', 0, 'http://localhost:8888/habitat/?p=7', 1, 'nav_menu_item', '', 0),
(11, 1, '2018-12-05 17:22:58', '2018-12-05 17:22:58', '', 'Donate', '', 'publish', 'closed', 'closed', '', 'contact', '', '', '2019-01-09 16:08:48', '2019-01-09 16:08:48', '', 0, 'http://localhost:8888/habitat/?p=11', 6, 'nav_menu_item', '', 0),
(12, 1, '2018-12-05 17:47:30', '2018-12-05 17:47:30', '<h1>Heading 1</h1>\r\n<h2>Heading 2</h2>\r\n&nbsp;\r\n\r\nLorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor', 'Test', '', 'inherit', 'closed', 'closed', '', '5-revision-v1', '', '', '2018-12-05 17:47:30', '2018-12-05 17:47:30', '', 5, 'http://localhost:8888/habitat/2018/12/05/5-revision-v1/', 0, 'revision', '', 0),
(14, 1, '2018-12-05 21:29:13', '2018-12-05 21:29:13', '<h1>Heading 1</h1>\nAn example of <strong>bold text</strong> followed by italics style, and then an un-ordered list:\n<ul>\n 	<li>apples</li>\n 	<li>bananas</li>\n 	<li>crepes</li>\n</ul>\nLorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor', 'Test', '', 'inherit', 'closed', 'closed', '', '5-autosave-v1', '', '', '2018-12-05 21:29:13', '2018-12-05 21:29:13', '', 5, 'http://localhost:8888/habitat/2018/12/05/5-autosave-v1/', 0, 'revision', '', 0),
(15, 1, '2018-12-05 21:29:18', '2018-12-05 21:29:18', '<h1>Heading 1</h1>\r\nAn example of <strong>bold text</strong> followed by italics style, and then an un-ordered list:\r\n<ul>\r\n 	<li>apples</li>\r\n 	<li>bananas</li>\r\n 	<li>crepes</li>\r\n</ul>\r\nLorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor', 'Test', '', 'inherit', 'closed', 'closed', '', '5-revision-v1', '', '', '2018-12-05 21:29:18', '2018-12-05 21:29:18', '', 5, 'http://localhost:8888/habitat/2018/12/05/5-revision-v1/', 0, 'revision', '', 0),
(16, 1, '2018-12-06 18:16:35', '2018-12-06 18:16:35', '<h1>Heading 1</h1>\r\nAn example of <strong>bold text</strong> followed by <em>italics style</em>, and then an un-ordered list:\r\n<ul>\r\n 	<li>apples</li>\r\n 	<li>bananas</li>\r\n 	<li>crepes</li>\r\n</ul>\r\nLorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor', 'Test', '', 'inherit', 'closed', 'closed', '', '5-revision-v1', '', '', '2018-12-06 18:16:35', '2018-12-06 18:16:35', '', 5, 'http://localhost:8888/habitat/2018/12/06/5-revision-v1/', 0, 'revision', '', 0),
(17, 1, '2018-12-06 18:17:23', '2018-12-06 18:17:23', '<h1>Heading 1</h1>\r\nAn example of <strong>bold text</strong> followed by <em>italics style</em>, and then an un-ordered list:\r\n<ul>\r\n 	<li>apples</li>\r\n 	<li>bananas</li>\r\n 	<li>crepes</li>\r\n</ul>\r\nLorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolorLorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum \r\n\r\nLorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum \r\n\r\nLorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum Lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum Lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum Lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum Lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum Lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum ', 'Test', '', 'inherit', 'closed', 'closed', '', '5-revision-v1', '', '', '2018-12-06 18:17:23', '2018-12-06 18:17:23', '', 5, 'http://localhost:8888/habitat/2018/12/06/5-revision-v1/', 0, 'revision', '', 0),
(18, 1, '2018-12-06 18:23:56', '2018-12-06 18:23:56', '<h1>Heading 1</h1>\r\nAn example of <strong>bold text</strong> followed by <em>italics style</em>, and then an un-ordered list:\r\n<ul>\r\n 	<li>apples</li>\r\n 	<li>bananas</li>\r\n 	<li>crepes</li>\r\n</ul>\r\nLorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolorLorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum \r\n\r\nLorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum \r\nm dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum Lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum ', 'Test', '', 'inherit', 'closed', 'closed', '', '5-revision-v1', '', '', '2018-12-06 18:23:56', '2018-12-06 18:23:56', '', 5, 'http://localhost:8888/habitat/2018/12/06/5-revision-v1/', 0, 'revision', '', 0),
(19, 1, '2018-12-06 18:24:03', '2018-12-06 18:24:03', '<h1>Heading 1</h1>\r\nAn example of <strong>bold text</strong> followed by <em>italics style</em>, and then an un-ordered list:\r\n<ul>\r\n 	<li>apples</li>\r\n 	<li>bananas</li>\r\n 	<li>crepes</li>\r\n</ul>\r\nLorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolorLorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ippsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum Lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum dolor lorem ipsum ', 'Test', '', 'inherit', 'closed', 'closed', '', '5-revision-v1', '', '', '2018-12-06 18:24:03', '2018-12-06 18:24:03', '', 5, 'http://localhost:8888/habitat/2018/12/06/5-revision-v1/', 0, 'revision', '', 0),
(20, 1, '2018-12-11 19:37:09', '2018-12-11 19:37:09', '', 'Our Families', '', 'publish', 'closed', 'closed', '', 'our-families', '', '', '2018-12-11 19:55:50', '2018-12-11 19:55:50', '', 0, 'http://localhost:8888/habitat/?p=20', 1, 'nav_menu_item', '', 0),
(21, 1, '2018-12-11 19:37:09', '2018-12-11 19:37:09', '', 'ReStore', '', 'publish', 'closed', 'closed', '', 'restore', '', '', '2018-12-11 19:55:50', '2018-12-11 19:55:50', '', 0, 'http://localhost:8888/habitat/?p=21', 2, 'nav_menu_item', '', 0),
(22, 1, '2018-12-11 19:37:09', '2018-12-11 19:37:09', '', 'News', '', 'publish', 'closed', 'closed', '', 'news', '', '', '2018-12-11 19:55:50', '2018-12-11 19:55:50', '', 0, 'http://localhost:8888/habitat/?p=22', 3, 'nav_menu_item', '', 0),
(23, 1, '2018-12-12 16:41:46', '2018-12-12 16:41:46', '', 'Home', '', 'publish', 'closed', 'closed', '', 'home', '', '', '2019-01-11 18:55:46', '2019-01-11 18:55:46', '', 0, 'http://localhost:8888/habitat/?page_id=23', 0, 'page', '', 0),
(24, 1, '2018-12-12 16:41:13', '2018-12-12 16:41:13', '', 'Home', '', 'inherit', 'closed', 'closed', '', '23-revision-v1', '', '', '2018-12-12 16:41:13', '2018-12-12 16:41:13', '', 23, 'http://localhost:8888/habitat/2018/12/12/23-revision-v1/', 0, 'revision', '', 0),
(26, 1, '2019-01-08 15:53:19', '2019-01-08 15:53:19', '', 'Apply', '', 'publish', 'closed', 'closed', '', 'apply', '', '', '2019-01-08 16:03:19', '2019-01-08 16:03:19', '', 0, 'http://localhost:8888/habitat/?page_id=26', 1, 'page', '', 0),
(27, 1, '2019-01-08 15:53:19', '2019-01-08 15:53:19', '', 'Apply', '', 'inherit', 'closed', 'closed', '', '26-revision-v1', '', '', '2019-01-08 15:53:19', '2019-01-08 15:53:19', '', 26, 'http://localhost:8888/habitat/2019/01/08/26-revision-v1/', 0, 'revision', '', 0),
(28, 1, '2019-01-09 16:06:01', '2019-01-09 16:06:01', '', 'Volunteer', '', 'publish', 'closed', 'closed', '', 'volunteer', '', '', '2019-01-09 16:06:01', '2019-01-09 16:06:01', '', 0, 'http://localhost:8888/habitat/?page_id=28', 0, 'page', '', 0),
(29, 1, '2019-01-09 16:06:18', '2019-01-09 16:06:18', '', 'Who We Are', '', 'publish', 'closed', 'closed', '', 'who-we-are', '', '', '2019-01-09 17:05:12', '2019-01-09 17:05:12', '', 0, 'http://localhost:8888/habitat/?page_id=29', 0, 'page', '', 0),
(30, 1, '2019-01-09 16:06:01', '2019-01-09 16:06:01', '', 'Volunteer', '', 'inherit', 'closed', 'closed', '', '28-revision-v1', '', '', '2019-01-09 16:06:01', '2019-01-09 16:06:01', '', 28, 'http://localhost:8888/habitat/2019/01/09/28-revision-v1/', 0, 'revision', '', 0),
(31, 1, '2019-01-09 16:06:18', '2019-01-09 16:06:18', '', 'Who We Are', '', 'inherit', 'closed', 'closed', '', '29-revision-v1', '', '', '2019-01-09 16:06:18', '2019-01-09 16:06:18', '', 29, 'http://localhost:8888/habitat/2019/01/09/29-revision-v1/', 0, 'revision', '', 0),
(32, 1, '2019-01-09 16:07:17', '2019-01-09 16:07:17', '', 'Standard Page', '', 'publish', 'closed', 'closed', '', 'standard-page', '', '', '2019-01-10 15:06:48', '2019-01-10 15:06:48', '', 0, 'http://localhost:8888/habitat/?page_id=32', 9, 'page', '', 0),
(33, 1, '2019-01-09 16:07:17', '2019-01-09 16:07:17', '', 'Standard Page', '', 'inherit', 'closed', 'closed', '', '32-revision-v1', '', '', '2019-01-09 16:07:17', '2019-01-09 16:07:17', '', 32, 'http://localhost:8888/habitat/2019/01/09/32-revision-v1/', 0, 'revision', '', 0),
(34, 1, '2019-01-09 16:07:20', '2019-01-09 16:07:20', '', 'Standard', '', 'inherit', 'closed', 'closed', '', '32-revision-v1', '', '', '2019-01-09 16:07:20', '2019-01-09 16:07:20', '', 32, 'http://localhost:8888/habitat/2019/01/09/32-revision-v1/', 0, 'revision', '', 0),
(35, 1, '2019-01-09 16:08:40', '2019-01-09 16:08:40', ' ', '', '', 'publish', 'closed', 'closed', '', '35', '', '', '2019-01-09 16:08:48', '2019-01-09 16:08:48', '', 0, 'http://localhost:8888/habitat/?p=35', 2, 'nav_menu_item', '', 0),
(36, 1, '2019-01-09 16:08:40', '2019-01-09 16:08:40', ' ', '', '', 'publish', 'closed', 'closed', '', '36', '', '', '2019-01-09 16:08:48', '2019-01-09 16:08:48', '', 0, 'http://localhost:8888/habitat/?p=36', 3, 'nav_menu_item', '', 0),
(37, 1, '2019-01-09 16:08:40', '2019-01-09 16:08:40', ' ', '', '', 'publish', 'closed', 'closed', '', '37', '', '', '2019-01-09 16:08:48', '2019-01-09 16:08:48', '', 0, 'http://localhost:8888/habitat/?p=37', 5, 'nav_menu_item', '', 0),
(38, 1, '2019-01-09 16:08:37', '2019-01-09 16:08:37', '', 'Ways to Give', '', 'publish', 'closed', 'closed', '', 'ways-to-give', '', '', '2019-01-09 16:08:37', '2019-01-09 16:08:37', '', 0, 'http://localhost:8888/habitat/?page_id=38', 0, 'page', '', 0),
(39, 1, '2019-01-09 16:08:37', '2019-01-09 16:08:37', '', 'Ways to Give', '', 'inherit', 'closed', 'closed', '', '38-revision-v1', '', '', '2019-01-09 16:08:37', '2019-01-09 16:08:37', '', 38, 'http://localhost:8888/habitat/2019/01/09/38-revision-v1/', 0, 'revision', '', 0),
(40, 1, '2019-01-09 16:08:48', '2019-01-09 16:08:48', ' ', '', '', 'publish', 'closed', 'closed', '', '40', '', '', '2019-01-09 16:08:48', '2019-01-09 16:08:48', '', 0, 'http://localhost:8888/habitat/?p=40', 4, 'nav_menu_item', '', 0),
(41, 1, '2019-01-10 15:06:48', '2019-01-10 15:06:48', '', 'Standard Page', '', 'inherit', 'closed', 'closed', '', '32-revision-v1', '', '', '2019-01-10 15:06:48', '2019-01-10 15:06:48', '', 32, 'http://localhost:8888/habitat/2019/01/10/32-revision-v1/', 0, 'revision', '', 0),
(42, 1, '2019-01-10 15:07:17', '2019-01-10 15:07:17', '', 'Example Article', '', 'publish', 'open', 'open', '', 'example-article', '', '', '2019-01-10 15:07:17', '2019-01-10 15:07:17', '', 0, 'http://localhost:8888/habitat/?p=42', 0, 'post', '', 0),
(43, 1, '2019-01-10 15:07:17', '2019-01-10 15:07:17', '', 'Example Article', '', 'inherit', 'closed', 'closed', '', '42-revision-v1', '', '', '2019-01-10 15:07:17', '2019-01-10 15:07:17', '', 42, 'http://localhost:8888/habitat/2019/01/10/42-revision-v1/', 0, 'revision', '', 0),
(44, 1, '2019-01-10 15:08:09', '2019-01-10 15:08:09', '', 'News', '', 'publish', 'closed', 'closed', '', 'news', '', '', '2019-01-10 15:08:09', '2019-01-10 15:08:09', '', 0, 'http://localhost:8888/habitat/?page_id=44', 0, 'page', '', 0),
(45, 1, '2019-01-10 15:08:09', '2019-01-10 15:08:09', '', 'News', '', 'inherit', 'closed', 'closed', '', '44-revision-v1', '', '', '2019-01-10 15:08:09', '2019-01-10 15:08:09', '', 44, 'http://localhost:8888/habitat/2019/01/10/44-revision-v1/', 0, 'revision', '', 0),
(46, 1, '2019-01-10 15:08:21', '2019-01-10 15:08:21', '', 'Our Families', '', 'publish', 'closed', 'closed', '', 'our-families', '', '', '2019-01-10 15:08:21', '2019-01-10 15:08:21', '', 0, 'http://localhost:8888/habitat/?page_id=46', 0, 'page', '', 0),
(47, 1, '2019-01-10 15:08:21', '2019-01-10 15:08:21', '', 'Our Families', '', 'inherit', 'closed', 'closed', '', '46-revision-v1', '', '', '2019-01-10 15:08:21', '2019-01-10 15:08:21', '', 46, 'http://localhost:8888/habitat/2019/01/10/46-revision-v1/', 0, 'revision', '', 0),
(48, 1, '2019-01-10 15:08:34', '2019-01-10 15:08:34', '', 'ReStore', '', 'publish', 'closed', 'closed', '', 'restore', '', '', '2019-01-10 15:08:34', '2019-01-10 15:08:34', '', 0, 'http://localhost:8888/habitat/?page_id=48', 0, 'page', '', 0),
(49, 1, '2019-01-10 15:08:34', '2019-01-10 15:08:34', '', 'ReStore', '', 'inherit', 'closed', 'closed', '', '48-revision-v1', '', '', '2019-01-10 15:08:34', '2019-01-10 15:08:34', '', 48, 'http://localhost:8888/habitat/2019/01/10/48-revision-v1/', 0, 'revision', '', 0),
(52, 1, '2019-01-10 21:29:01', '2019-01-10 21:29:01', 'a:7:{s:8:"location";a:1:{i:0;a:1:{i:0;a:3:{s:5:"param";s:13:"page_template";s:8:"operator";s:2:"==";s:5:"value";s:13:"page-home.php";}}}s:8:"position";s:6:"normal";s:5:"style";s:7:"default";s:15:"label_placement";s:3:"top";s:21:"instruction_placement";s:5:"label";s:14:"hide_on_screen";s:0:"";s:11:"description";s:0:"";}', 'Homepage - Featured Banner', 'homepage-featured-banner', 'publish', 'closed', 'closed', '', 'group_5c37b8f1333ca', '', '', '2019-01-11 18:23:06', '2019-01-11 18:23:06', '', 0, 'http://localhost:8888/habitat/?post_type=acf-field-group&#038;p=52', 0, 'acf-field-group', '', 0),
(53, 1, '2019-01-10 21:29:01', '2019-01-10 21:29:01', 'a:15:{s:4:"type";s:5:"image";s:12:"instructions";s:0:"";s:8:"required";i:1;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"return_format";s:3:"url";s:12:"preview_size";s:6:"medium";s:7:"library";s:3:"all";s:9:"min_width";s:0:"";s:10:"min_height";s:0:"";s:8:"min_size";s:0:"";s:9:"max_width";s:0:"";s:10:"max_height";s:0:"";s:8:"max_size";s:0:"";s:10:"mime_types";s:0:"";}', 'Featured Banner', 'featured_banner', 'publish', 'closed', 'closed', '', 'field_5c37b8f643fd0', '', '', '2019-01-10 21:29:01', '2019-01-10 21:29:01', '', 52, 'http://localhost:8888/habitat/?post_type=acf-field&p=53', 0, 'acf-field', '', 0),
(54, 1, '2019-01-10 21:31:53', '2019-01-10 21:31:53', '', 'Bloom Frame Up Day-69', '', 'inherit', 'open', 'closed', '', 'bloom-frame-up-day-69', '', '', '2019-01-10 21:31:53', '2019-01-10 21:31:53', '', 23, 'http://localhost:8888/habitat/wp-content/uploads/2019/01/Bloom-Frame-Up-Day-69.jpg', 0, 'attachment', 'image/jpeg', 0),
(55, 1, '2019-01-10 21:32:39', '2019-01-10 21:32:39', '', 'Home', '', 'inherit', 'closed', 'closed', '', '23-revision-v1', '', '', '2019-01-10 21:32:39', '2019-01-10 21:32:39', '', 23, 'http://localhost:8888/habitat/2019/01/10/23-revision-v1/', 0, 'revision', '', 0),
(56, 1, '2019-01-10 21:57:30', '2019-01-10 21:57:30', 'a:10:{s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:9:"maxlength";s:0:"";}', 'Featured Banner Text', 'featured_banner_text', 'publish', 'closed', 'closed', '', 'field_5c37bf64d648d', '', '', '2019-01-10 21:57:30', '2019-01-10 21:57:30', '', 52, 'http://localhost:8888/habitat/?post_type=acf-field&p=56', 1, 'acf-field', '', 0),
(57, 1, '2019-01-10 21:57:52', '2019-01-10 21:57:52', '', 'Home', '', 'inherit', 'closed', 'closed', '', '23-revision-v1', '', '', '2019-01-10 21:57:52', '2019-01-10 21:57:52', '', 23, 'http://localhost:8888/habitat/2019/01/10/23-revision-v1/', 0, 'revision', '', 0),
(58, 1, '2019-01-11 16:35:13', '2019-01-11 16:35:13', 'Welcome to WordPress. This is your first post. Edit or delete it, then start writing!', 'Hello world!', '', 'inherit', 'closed', 'closed', '', '1-revision-v1', '', '', '2019-01-11 16:35:13', '2019-01-11 16:35:13', '', 1, 'http://localhost:8888/habitat/2019/01/11/1-revision-v1/', 0, 'revision', '', 0),
(59, 1, '2019-01-11 16:35:26', '0000-00-00 00:00:00', '', 'Auto Draft', '', 'auto-draft', 'closed', 'closed', '', '', '', '', '2019-01-11 16:35:26', '0000-00-00 00:00:00', '', 0, 'http://localhost:8888/habitat/?page_id=59', 0, 'page', '', 0),
(63, 1, '2019-01-11 16:53:41', '2019-01-11 16:53:41', '', 'Home', '', 'inherit', 'closed', 'closed', '', '23-revision-v1', '', '', '2019-01-11 16:53:41', '2019-01-11 16:53:41', '', 23, 'http://localhost:8888/habitat/2019/01/11/23-revision-v1/', 0, 'revision', '', 0),
(64, 1, '2019-01-11 16:53:59', '2019-01-11 16:53:59', '', 'Home', '', 'inherit', 'closed', 'closed', '', '23-revision-v1', '', '', '2019-01-11 16:53:59', '2019-01-11 16:53:59', '', 23, 'http://localhost:8888/habitat/2019/01/11/23-revision-v1/', 0, 'revision', '', 0),
(65, 1, '2019-01-11 18:18:56', '0000-00-00 00:00:00', '', 'Auto Draft', '', 'auto-draft', 'open', 'open', '', '', '', '', '2019-01-11 18:18:56', '0000-00-00 00:00:00', '', 0, 'http://localhost:8888/habitat/?p=65', 0, 'post', '', 0),
(68, 1, '2019-01-11 18:22:44', '2019-01-11 18:22:44', 'a:7:{s:8:"location";a:1:{i:0;a:1:{i:0;a:3:{s:5:"param";s:13:"page_template";s:8:"operator";s:2:"==";s:5:"value";s:13:"page-home.php";}}}s:8:"position";s:6:"normal";s:5:"style";s:7:"default";s:15:"label_placement";s:3:"top";s:21:"instruction_placement";s:5:"label";s:14:"hide_on_screen";s:0:"";s:11:"description";s:0:"";}', 'Homepage - 3 Main Modules', 'homepage-3-main-modules', 'publish', 'closed', 'closed', '', 'group_5c38def4172bb', '', '', '2019-01-11 18:23:45', '2019-01-11 18:23:45', '', 0, 'http://localhost:8888/habitat/?post_type=acf-field-group&#038;p=68', 0, 'acf-field-group', '', 0),
(71, 1, '2019-01-11 18:22:44', '2019-01-11 18:22:44', 'a:10:{s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:1;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:9:"maxlength";s:0:"";}', 'Row 1 - Homeowner Text', 'homeowner_text', 'publish', 'closed', 'closed', '', 'field_5c38def41c243', '', '', '2019-01-11 18:23:26', '2019-01-11 18:23:26', '', 68, 'http://localhost:8888/habitat/?post_type=acf-field&#038;p=71', 0, 'acf-field', '', 0),
(72, 1, '2019-01-11 18:22:44', '2019-01-11 18:22:44', 'a:10:{s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:1;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:9:"maxlength";s:0:"";}', 'Row 1 - Volunteer Text', 'volunteer_text', 'publish', 'closed', 'closed', '', 'field_5c38def41c253', '', '', '2019-01-11 18:23:26', '2019-01-11 18:23:26', '', 68, 'http://localhost:8888/habitat/?post_type=acf-field&#038;p=72', 1, 'acf-field', '', 0),
(73, 1, '2019-01-11 18:22:44', '2019-01-11 18:22:44', 'a:10:{s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:1;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:9:"maxlength";s:0:"";}', 'Row 1 - ReStore Text', 'restore_text', 'publish', 'closed', 'closed', '', 'field_5c38def41c262', '', '', '2019-01-11 18:23:26', '2019-01-11 18:23:26', '', 68, 'http://localhost:8888/habitat/?post_type=acf-field&#038;p=73', 2, 'acf-field', '', 0),
(76, 1, '2019-01-11 18:23:31', '2019-01-11 18:23:31', 'a:7:{s:8:"location";a:1:{i:0;a:1:{i:0;a:3:{s:5:"param";s:13:"page_template";s:8:"operator";s:2:"==";s:5:"value";s:13:"page-home.php";}}}s:8:"position";s:6:"normal";s:5:"style";s:7:"default";s:15:"label_placement";s:3:"top";s:21:"instruction_placement";s:5:"label";s:14:"hide_on_screen";s:0:"";s:11:"description";s:0:"";}', 'Homepage - Mission Statement', 'homepage-mission-statement', 'publish', 'closed', 'closed', '', 'group_5c38df23e4898', '', '', '2019-01-11 18:25:50', '2019-01-11 18:25:50', '', 0, 'http://localhost:8888/habitat/?post_type=acf-field-group&#038;p=76', 0, 'acf-field-group', '', 0),
(79, 1, '2019-01-11 18:24:56', '2019-01-11 18:24:56', 'a:10:{s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:1;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:9:"maxlength";s:0:"";}', 'Main Text', 'mission_statement', 'publish', 'closed', 'closed', '', 'field_5c38df69cf456', '', '', '2019-01-11 18:24:56', '2019-01-11 18:24:56', '', 76, 'http://localhost:8888/habitat/?post_type=acf-field&p=79', 0, 'acf-field', '', 0),
(80, 1, '2019-01-11 18:25:31', '2019-01-11 18:25:31', 'a:10:{s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:1;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:9:"maxlength";s:0:"";}', 'Sub Text', 'mission_statement_subtext', 'publish', 'closed', 'closed', '', 'field_5c38df95912ef', '', '', '2019-01-11 18:25:50', '2019-01-11 18:25:50', '', 76, 'http://localhost:8888/habitat/?post_type=acf-field&#038;p=80', 1, 'acf-field', '', 0),
(81, 1, '2019-01-11 18:26:02', '2019-01-11 18:26:02', '', 'Home', '', 'inherit', 'closed', 'closed', '', '23-revision-v1', '', '', '2019-01-11 18:26:02', '2019-01-11 18:26:02', '', 23, 'http://localhost:8888/habitat/2019/01/11/23-revision-v1/', 0, 'revision', '', 0),
(82, 1, '2019-01-11 18:26:20', '2019-01-11 18:26:20', '', 'Home', '', 'inherit', 'closed', 'closed', '', '23-revision-v1', '', '', '2019-01-11 18:26:20', '2019-01-11 18:26:20', '', 23, 'http://localhost:8888/habitat/2019/01/11/23-revision-v1/', 0, 'revision', '', 0),
(83, 1, '2019-01-11 18:52:41', '2019-01-11 18:52:41', 'a:7:{s:8:"location";a:1:{i:0;a:1:{i:0;a:3:{s:5:"param";s:13:"page_template";s:8:"operator";s:2:"==";s:5:"value";s:13:"page-home.php";}}}s:8:"position";s:6:"normal";s:5:"style";s:7:"default";s:15:"label_placement";s:3:"top";s:21:"instruction_placement";s:5:"label";s:14:"hide_on_screen";s:0:"";s:11:"description";s:0:"";}', 'Homepage - Donate Button', 'homepage-donate-button', 'publish', 'closed', 'closed', '', 'group_5c38e5dfc340c', '', '', '2019-01-11 18:53:04', '2019-01-11 18:53:04', '', 0, 'http://localhost:8888/habitat/?post_type=acf-field-group&#038;p=83', 0, 'acf-field-group', '', 0),
(84, 1, '2019-01-11 18:52:41', '2019-01-11 18:52:41', 'a:10:{s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:1;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:9:"maxlength";s:0:"";}', 'Donate Button Text', 'donate_button_text', 'publish', 'closed', 'closed', '', 'field_5c38e5e597eb3', '', '', '2019-01-11 18:52:41', '2019-01-11 18:52:41', '', 83, 'http://localhost:8888/habitat/?post_type=acf-field&p=84', 0, 'acf-field', '', 0),
(85, 1, '2019-01-11 18:53:04', '2019-01-11 18:53:04', 'a:7:{s:4:"type";s:3:"url";s:12:"instructions";s:0:"";s:8:"required";i:1;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";}', 'Donate Button URL', 'donate_button_url', 'publish', 'closed', 'closed', '', 'field_5c38e5fb84046', '', '', '2019-01-11 18:53:04', '2019-01-11 18:53:04', '', 83, 'http://localhost:8888/habitat/?post_type=acf-field&p=85', 1, 'acf-field', '', 0),
(86, 1, '2019-01-11 18:54:07', '2019-01-11 18:54:07', '', 'Home', '', 'inherit', 'closed', 'closed', '', '23-revision-v1', '', '', '2019-01-11 18:54:07', '2019-01-11 18:54:07', '', 23, 'http://localhost:8888/habitat/2019/01/11/23-revision-v1/', 0, 'revision', '', 0),
(87, 1, '2019-01-11 18:54:27', '0000-00-00 00:00:00', '', 'Auto Draft', '', 'auto-draft', 'closed', 'closed', '', '', '', '', '2019-01-11 18:54:27', '0000-00-00 00:00:00', '', 0, 'http://localhost:8888/habitat/?post_type=acf-field-group&p=87', 0, 'acf-field-group', '', 0),
(88, 1, '2019-01-11 18:54:34', '2019-01-11 18:54:34', 'a:7:{s:8:"location";a:1:{i:0;a:1:{i:0;a:3:{s:5:"param";s:13:"page_template";s:8:"operator";s:2:"==";s:5:"value";s:13:"page-home.php";}}}s:8:"position";s:6:"normal";s:5:"style";s:7:"default";s:15:"label_placement";s:3:"top";s:21:"instruction_placement";s:5:"label";s:14:"hide_on_screen";s:0:"";s:11:"description";s:0:"";}', 'Homepage - Families Button', 'homepage-families-button', 'publish', 'closed', 'closed', '', 'group_5c38e66a1f4bf', '', '', '2019-01-11 18:55:06', '2019-01-11 18:55:06', '', 0, 'http://localhost:8888/habitat/?post_type=acf-field-group&#038;p=88', 0, 'acf-field-group', '', 0),
(89, 1, '2019-01-11 18:54:34', '2019-01-11 18:54:34', 'a:10:{s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:1;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:9:"maxlength";s:0:"";}', 'Families Button Text', 'families_button_text', 'publish', 'closed', 'closed', '', 'field_5c38e66a244c8', '', '', '2019-01-11 18:54:54', '2019-01-11 18:54:54', '', 88, 'http://localhost:8888/habitat/?post_type=acf-field&#038;p=89', 0, 'acf-field', '', 0),
(90, 1, '2019-01-11 18:54:34', '2019-01-11 18:54:34', 'a:7:{s:4:"type";s:3:"url";s:12:"instructions";s:0:"";s:8:"required";i:1;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";}', 'Families Button URL', 'families_button_url', 'publish', 'closed', 'closed', '', 'field_5c38e66a244dd', '', '', '2019-01-11 18:55:06', '2019-01-11 18:55:06', '', 88, 'http://localhost:8888/habitat/?post_type=acf-field&#038;p=90', 1, 'acf-field', '', 0),
(91, 1, '2019-01-11 18:55:46', '2019-01-11 18:55:46', '', 'Home', '', 'inherit', 'closed', 'closed', '', '23-revision-v1', '', '', '2019-01-11 18:55:46', '2019-01-11 18:55:46', '', 23, 'http://localhost:8888/habitat/2019/01/11/23-revision-v1/', 0, 'revision', '', 0),
(92, 1, '2019-01-11 19:34:27', '2019-01-11 19:34:27', ' ', '', '', 'publish', 'closed', 'closed', '', '92', '', '', '2019-01-11 19:46:01', '2019-01-11 19:46:01', '', 0, 'http://localhost:8888/habitat/?p=92', 2, 'nav_menu_item', '', 0),
(93, 1, '2019-01-11 19:34:27', '2019-01-11 19:34:27', ' ', '', '', 'publish', 'closed', 'closed', '', '93', '', '', '2019-01-11 19:46:01', '2019-01-11 19:46:01', '', 0, 'http://localhost:8888/habitat/?p=93', 3, 'nav_menu_item', '', 0),
(94, 1, '2019-01-11 19:34:27', '2019-01-11 19:34:27', ' ', '', '', 'publish', 'closed', 'closed', '', '94', '', '', '2019-01-11 19:46:01', '2019-01-11 19:46:01', '', 0, 'http://localhost:8888/habitat/?p=94', 4, 'nav_menu_item', '', 0),
(95, 1, '2019-01-11 19:34:27', '2019-01-11 19:34:27', ' ', '', '', 'publish', 'closed', 'closed', '', '95', '', '', '2019-01-11 19:46:01', '2019-01-11 19:46:01', '', 0, 'http://localhost:8888/habitat/?p=95', 5, 'nav_menu_item', '', 0),
(96, 1, '2019-01-11 19:34:27', '2019-01-11 19:34:27', ' ', '', '', 'publish', 'closed', 'closed', '', '96', '', '', '2019-01-11 19:46:01', '2019-01-11 19:46:01', '', 0, 'http://localhost:8888/habitat/?p=96', 6, 'nav_menu_item', '', 0),
(97, 1, '2019-01-11 19:34:27', '2019-01-11 19:34:27', ' ', '', '', 'publish', 'closed', 'closed', '', '97', '', '', '2019-01-11 19:46:01', '2019-01-11 19:46:01', '', 0, 'http://localhost:8888/habitat/?p=97', 1, 'nav_menu_item', '', 0),
(98, 1, '2019-01-11 19:34:27', '2019-01-11 19:34:27', ' ', '', '', 'publish', 'closed', 'closed', '', '98', '', '', '2019-01-11 19:46:01', '2019-01-11 19:46:01', '', 0, 'http://localhost:8888/habitat/?p=98', 7, 'nav_menu_item', '', 0),
(99, 1, '2019-01-11 19:45:54', '2019-01-11 19:45:54', ' ', '', '', 'publish', 'closed', 'closed', '', '99', '', '', '2019-01-11 19:45:54', '2019-01-11 19:45:54', '', 0, 'http://localhost:8888/habitat/?p=99', 2, 'nav_menu_item', '', 0),
(100, 1, '2019-01-11 19:45:54', '2019-01-11 19:45:54', ' ', '', '', 'publish', 'closed', 'closed', '', '100', '', '', '2019-01-11 19:45:54', '2019-01-11 19:45:54', '', 0, 'http://localhost:8888/habitat/?p=100', 3, 'nav_menu_item', '', 0),
(101, 1, '2019-01-11 19:45:54', '2019-01-11 19:45:54', ' ', '', '', 'publish', 'closed', 'closed', '', '101', '', '', '2019-01-11 19:45:54', '2019-01-11 19:45:54', '', 0, 'http://localhost:8888/habitat/?p=101', 4, 'nav_menu_item', '', 0),
(102, 1, '2019-01-11 19:45:54', '2019-01-11 19:45:54', ' ', '', '', 'publish', 'closed', 'closed', '', '102', '', '', '2019-01-11 19:45:54', '2019-01-11 19:45:54', '', 0, 'http://localhost:8888/habitat/?p=102', 1, 'nav_menu_item', '', 0),
(103, 1, '2019-01-11 19:45:54', '2019-01-11 19:45:54', ' ', '', '', 'publish', 'closed', 'closed', '', '103', '', '', '2019-01-11 19:45:54', '2019-01-11 19:45:54', '', 0, 'http://localhost:8888/habitat/?p=103', 5, 'nav_menu_item', '', 0),
(104, 1, '2019-01-11 19:45:54', '2019-01-11 19:45:54', ' ', '', '', 'publish', 'closed', 'closed', '', '104', '', '', '2019-01-11 19:45:54', '2019-01-11 19:45:54', '', 0, 'http://localhost:8888/habitat/?p=104', 6, 'nav_menu_item', '', 0),
(105, 1, '2019-01-11 19:46:36', '2019-01-11 19:46:36', ' ', '', '', 'publish', 'closed', 'closed', '', '105', '', '', '2019-01-11 19:46:36', '2019-01-11 19:46:36', '', 0, 'http://localhost:8888/habitat/?p=105', 1, 'nav_menu_item', '', 0),
(106, 1, '2019-01-11 19:46:36', '2019-01-11 19:46:36', ' ', '', '', 'publish', 'closed', 'closed', '', '106', '', '', '2019-01-11 19:46:36', '2019-01-11 19:46:36', '', 0, 'http://localhost:8888/habitat/?p=106', 2, 'nav_menu_item', '', 0),
(107, 1, '2019-01-11 19:46:36', '2019-01-11 19:46:36', ' ', '', '', 'publish', 'closed', 'closed', '', '107', '', '', '2019-01-11 19:46:36', '2019-01-11 19:46:36', '', 0, 'http://localhost:8888/habitat/?p=107', 3, 'nav_menu_item', '', 0),
(108, 1, '2019-01-11 19:46:36', '2019-01-11 19:46:36', ' ', '', '', 'publish', 'closed', 'closed', '', '108', '', '', '2019-01-11 19:46:36', '2019-01-11 19:46:36', '', 0, 'http://localhost:8888/habitat/?p=108', 4, 'nav_menu_item', '', 0),
(109, 1, '2019-01-11 19:46:36', '2019-01-11 19:46:36', ' ', '', '', 'publish', 'closed', 'closed', '', '109', '', '', '2019-01-11 19:46:36', '2019-01-11 19:46:36', '', 0, 'http://localhost:8888/habitat/?p=109', 5, 'nav_menu_item', '', 0),
(110, 1, '2019-01-11 19:46:57', '2019-01-11 19:46:57', ' ', '', '', 'publish', 'closed', 'closed', '', '110', '', '', '2019-01-11 19:46:57', '2019-01-11 19:46:57', '', 0, 'http://localhost:8888/habitat/?p=110', 2, 'nav_menu_item', '', 0),
(111, 1, '2019-01-11 19:46:57', '2019-01-11 19:46:57', ' ', '', '', 'publish', 'closed', 'closed', '', '111', '', '', '2019-01-11 19:46:57', '2019-01-11 19:46:57', '', 0, 'http://localhost:8888/habitat/?p=111', 3, 'nav_menu_item', '', 0),
(112, 1, '2019-01-11 19:46:57', '2019-01-11 19:46:57', ' ', '', '', 'publish', 'closed', 'closed', '', '112', '', '', '2019-01-11 19:46:57', '2019-01-11 19:46:57', '', 0, 'http://localhost:8888/habitat/?p=112', 4, 'nav_menu_item', '', 0),
(113, 1, '2019-01-11 19:46:58', '2019-01-11 19:46:58', ' ', '', '', 'publish', 'closed', 'closed', '', '113', '', '', '2019-01-11 19:46:58', '2019-01-11 19:46:58', '', 0, 'http://localhost:8888/habitat/?p=113', 5, 'nav_menu_item', '', 0),
(114, 1, '2019-01-11 19:46:58', '2019-01-11 19:46:58', ' ', '', '', 'publish', 'closed', 'closed', '', '114', '', '', '2019-01-11 19:46:58', '2019-01-11 19:46:58', '', 0, 'http://localhost:8888/habitat/?p=114', 6, 'nav_menu_item', '', 0),
(115, 1, '2019-01-11 19:46:58', '2019-01-11 19:46:58', ' ', '', '', 'publish', 'closed', 'closed', '', '115', '', '', '2019-01-11 19:46:58', '2019-01-11 19:46:58', '', 0, 'http://localhost:8888/habitat/?p=115', 7, 'nav_menu_item', '', 0),
(116, 1, '2019-01-11 19:46:57', '2019-01-11 19:46:57', ' ', '', '', 'publish', 'closed', 'closed', '', '116', '', '', '2019-01-11 19:46:57', '2019-01-11 19:46:57', '', 0, 'http://localhost:8888/habitat/?p=116', 1, 'nav_menu_item', '', 0) ;

#
# End of data contents of table `wp_posts`
# --------------------------------------------------------



#
# Delete any existing table `wp_term_relationships`
#

DROP TABLE IF EXISTS `wp_term_relationships`;


#
# Table structure of table `wp_term_relationships`
#

CREATE TABLE `wp_term_relationships` (
  `object_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `term_taxonomy_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `term_order` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`object_id`,`term_taxonomy_id`),
  KEY `term_taxonomy_id` (`term_taxonomy_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_term_relationships`
#
INSERT INTO `wp_term_relationships` ( `object_id`, `term_taxonomy_id`, `term_order`) VALUES
(1, 1, 0),
(7, 2, 0),
(11, 2, 0),
(20, 3, 0),
(21, 3, 0),
(22, 3, 0),
(35, 2, 0),
(36, 2, 0),
(37, 2, 0),
(40, 2, 0),
(42, 4, 0),
(92, 5, 0),
(93, 5, 0),
(94, 5, 0),
(95, 5, 0),
(96, 5, 0),
(97, 5, 0),
(98, 5, 0),
(99, 6, 0),
(100, 6, 0),
(101, 6, 0),
(102, 6, 0),
(103, 6, 0),
(104, 6, 0),
(105, 7, 0),
(106, 7, 0),
(107, 7, 0),
(108, 7, 0),
(109, 7, 0),
(110, 8, 0),
(111, 8, 0),
(112, 8, 0),
(113, 8, 0),
(114, 8, 0),
(115, 8, 0),
(116, 8, 0) ;

#
# End of data contents of table `wp_term_relationships`
# --------------------------------------------------------



#
# Delete any existing table `wp_term_taxonomy`
#

DROP TABLE IF EXISTS `wp_term_taxonomy`;


#
# Table structure of table `wp_term_taxonomy`
#

CREATE TABLE `wp_term_taxonomy` (
  `term_taxonomy_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `term_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `taxonomy` varchar(32) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `description` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `count` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`term_taxonomy_id`),
  UNIQUE KEY `term_id_taxonomy` (`term_id`,`taxonomy`),
  KEY `taxonomy` (`taxonomy`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_term_taxonomy`
#
INSERT INTO `wp_term_taxonomy` ( `term_taxonomy_id`, `term_id`, `taxonomy`, `description`, `parent`, `count`) VALUES
(1, 1, 'category', '', 0, 0),
(2, 2, 'nav_menu', '', 0, 6),
(3, 3, 'nav_menu', '', 0, 3),
(4, 4, 'category', '', 0, 1),
(5, 5, 'nav_menu', '', 0, 7),
(6, 6, 'nav_menu', '', 0, 6),
(7, 7, 'nav_menu', '', 0, 5),
(8, 8, 'nav_menu', '', 0, 7) ;

#
# End of data contents of table `wp_term_taxonomy`
# --------------------------------------------------------



#
# Delete any existing table `wp_termmeta`
#

DROP TABLE IF EXISTS `wp_termmeta`;


#
# Table structure of table `wp_termmeta`
#

CREATE TABLE `wp_termmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `term_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_520_ci,
  PRIMARY KEY (`meta_id`),
  KEY `term_id` (`term_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_termmeta`
#

#
# End of data contents of table `wp_termmeta`
# --------------------------------------------------------



#
# Delete any existing table `wp_terms`
#

DROP TABLE IF EXISTS `wp_terms`;


#
# Table structure of table `wp_terms`
#

CREATE TABLE `wp_terms` (
  `term_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `slug` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `term_group` bigint(10) NOT NULL DEFAULT '0',
  PRIMARY KEY (`term_id`),
  KEY `slug` (`slug`(191)),
  KEY `name` (`name`(191))
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_terms`
#
INSERT INTO `wp_terms` ( `term_id`, `name`, `slug`, `term_group`) VALUES
(1, 'Uncategorized', 'uncategorized', 0),
(2, 'Main Menu', 'main-menu', 0),
(3, 'Header Top', 'header-top', 0),
(4, 'News', 'news', 0),
(5, 'Footer - Who We Are', 'footer-who-we-are', 0),
(6, 'Footer - Volunteer', 'footer-volunteer', 0),
(7, 'Footer - Ways to Give', 'footer-ways-to-give', 0),
(8, 'Footer - Apply', 'footer-apply', 0) ;

#
# End of data contents of table `wp_terms`
# --------------------------------------------------------



#
# Delete any existing table `wp_usermeta`
#

DROP TABLE IF EXISTS `wp_usermeta`;


#
# Table structure of table `wp_usermeta`
#

CREATE TABLE `wp_usermeta` (
  `umeta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_520_ci,
  PRIMARY KEY (`umeta_id`),
  KEY `user_id` (`user_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB AUTO_INCREMENT=29 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_usermeta`
#
INSERT INTO `wp_usermeta` ( `umeta_id`, `user_id`, `meta_key`, `meta_value`) VALUES
(1, 1, 'nickname', 'blueline'),
(2, 1, 'first_name', ''),
(3, 1, 'last_name', ''),
(4, 1, 'description', ''),
(5, 1, 'rich_editing', 'true'),
(6, 1, 'syntax_highlighting', 'true'),
(7, 1, 'comment_shortcuts', 'false'),
(8, 1, 'admin_color', 'light'),
(9, 1, 'use_ssl', '0'),
(10, 1, 'show_admin_bar_front', 'true'),
(11, 1, 'locale', ''),
(12, 1, 'wp_capabilities', 'a:1:{s:13:"administrator";b:1;}'),
(13, 1, 'wp_user_level', '10'),
(14, 1, 'dismissed_wp_pointers', 'wp496_privacy'),
(15, 1, 'show_welcome_panel', '0'),
(16, 1, 'session_tokens', 'a:2:{s:64:"837d723e0b3ac56471958c24af1ab6dd76e92b3db7f8b986282c0a4d4623b39c";a:4:{s:10:"expiration";i:1547327674;s:2:"ip";s:3:"::1";s:2:"ua";s:82:"Mozilla/5.0 (Macintosh; Intel Mac OS X 10.13; rv:65.0) Gecko/20100101 Firefox/65.0";s:5:"login";i:1547154874;}s:64:"a4e4e21aec918c0599cd1f0c2af004cc681840b7e37efa995afffd6a52ccf6e4";a:4:{s:10:"expiration";i:1547396682;s:2:"ip";s:3:"::1";s:2:"ua";s:82:"Mozilla/5.0 (Macintosh; Intel Mac OS X 10.13; rv:65.0) Gecko/20100101 Firefox/65.0";s:5:"login";i:1547223882;}}'),
(17, 1, 'wp_dashboard_quick_press_last_post_id', '65'),
(18, 1, 'show_try_gutenberg_panel', '0'),
(19, 1, 'managenav-menuscolumnshidden', 'a:5:{i:0;s:11:"link-target";i:1;s:11:"css-classes";i:2;s:3:"xfn";i:3;s:11:"description";i:4;s:15:"title-attribute";}'),
(20, 1, 'metaboxhidden_nav-menus', 'a:1:{i:0;s:12:"add-post_tag";}'),
(21, 1, 'nav_menu_recently_edited', '8'),
(22, 1, 'wp_user-settings', 'editor=html&libraryContent=browse'),
(23, 1, 'wp_user-settings-time', '1547155955'),
(24, 1, 'community-events-location', 'a:1:{s:2:"ip";s:9:"127.0.0.0";}'),
(25, 1, 'closedpostboxes_page', 'a:2:{i:0;s:23:"acf-group_5c38def4172bb";i:1;s:23:"acf-group_5c37b8f1333ca";}'),
(26, 1, 'metaboxhidden_page', 'a:5:{i:0;s:12:"revisionsdiv";i:1;s:16:"commentstatusdiv";i:2;s:11:"commentsdiv";i:3;s:7:"slugdiv";i:4;s:9:"authordiv";}'),
(27, 1, 'meta-box-order_page', 'a:4:{s:15:"acf_after_title";s:0:"";s:4:"side";s:23:"submitdiv,pageparentdiv";s:6:"normal";s:131:"acf-group_5c37b8f1333ca,acf-group_5c38def4172bb,acf-group_5c38df23e4898,revisionsdiv,commentstatusdiv,commentsdiv,slugdiv,authordiv";s:8:"advanced";s:0:"";}'),
(28, 1, 'screen_layout_page', '2') ;

#
# End of data contents of table `wp_usermeta`
# --------------------------------------------------------



#
# Delete any existing table `wp_users`
#

DROP TABLE IF EXISTS `wp_users`;


#
# Table structure of table `wp_users`
#

CREATE TABLE `wp_users` (
  `ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_login` varchar(60) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_pass` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_nicename` varchar(50) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_email` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_url` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_registered` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `user_activation_key` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_status` int(11) NOT NULL DEFAULT '0',
  `display_name` varchar(250) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`ID`),
  KEY `user_login_key` (`user_login`),
  KEY `user_nicename` (`user_nicename`),
  KEY `user_email` (`user_email`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_users`
#
INSERT INTO `wp_users` ( `ID`, `user_login`, `user_pass`, `user_nicename`, `user_email`, `user_url`, `user_registered`, `user_activation_key`, `user_status`, `display_name`) VALUES
(1, 'blueline', '$P$BrIfybuahobi.C8abts9Z6Nn8oMWu40', 'blueline', 'admin@thisisblueline.com', '', '2018-11-27 19:38:15', '', 0, 'blueline') ;

#
# End of data contents of table `wp_users`
# --------------------------------------------------------

#
# Add constraints back in and apply any alter data queries.
#

